#!/bin/bash
set -euo pipefail
shopt -s nullglob

repo=/Users/brianglendenning/.codex/worktrees/5d43/casa-rs
runroot=/private/tmp/casa-t55-serial-ratio.OnKOSr
controller=/Users/brianglendenning/.agents/skills/codex-autoresearch/scripts
snapshot="$1"
mkdir "$snapshot"
python3 "$controller/autoresearch.py" status --repo "$repo" > "$snapshot/controller-status.json"
jq -e '.repository.consistent and (.repository.dirty_paths | length == 0)' "$snapshot/controller-status.json" >/dev/null
cp -R "$repo/autoresearch-results" "$snapshot/controller"
mkdir "$snapshot/experiment" "$snapshot/reference-reproduction" "$snapshot/controller-implementation"
cp "$runroot/config.json" "$runroot/frozen-controls.json" "$snapshot/experiment/"
cp "$controller"/*.py "$snapshot/controller-implementation/"
cp "$runroot"/*.log "$snapshot/experiment/"
cp /private/tmp/casa-t55-record.ngnwT1/t55-bounded-cube-refactor-brief.md "$snapshot/current-work-record.md"
cp "$runroot/pr-630-current-body.md" "$snapshot/pr-630-body.md"

mkdir "$snapshot/experiment/commits"
for trial in "$runroot"/commits/*; do
    [[ -d "$trial" ]] || continue
    revision="${trial##*/}"
    [[ "$revision" =~ ^[0-9a-f]{40}$ ]] || exit 1
    destination="$snapshot/experiment/commits/$revision"
    mkdir "$destination"
    for record in "$trial"/*.json "$trial"/*.log; do
        cp "$record" "$destination/"
    done
    for record in "$trial"/*/natural-w1/summary.json; do
        role="${record%/natural-w1/summary.json}"
        role="${role##*/}"
        cp "$record" "$destination/$role-summary.json"
    done
done

for profile in "$runroot"/profile-after-trial-*; do
    [[ -d "$profile" ]] || continue
    destination="$snapshot/experiment/${profile##*/}"
    mkdir "$destination"
    cp "$profile"/*.json "$profile"/*.log "$profile"/*.sample.txt "$destination/"
done

retained=$(jq -sr '[.[] | select(.event == "baseline" or (.event == "iteration" and .outcome == "keep"))][-1].head' "$repo/autoresearch-results/events.jsonl")
cp "$runroot/commits/$retained/application" "$snapshot/experiment/commits/$retained/application"
expected=$(jq -r .candidate_sha256 "$runroot/commits/$retained/measurement.json")
actual=$(shasum -a 256 "$snapshot/experiment/commits/$retained/application" | cut -d ' ' -f 1)
[[ "$expected" == "$actual" ]]

reference=/private/tmp/casa-t55-serial.d5AeGJ
cp "$reference/candidate-application" "$reference/measure.py" "$snapshot/reference-reproduction/"
cp "$repo/target/release/examples/initialize_imaging_owner" "$snapshot/reference-reproduction/"
cp "$reference/measured/request.json" "$reference/measured/results.json" "$reference/measured/exact-products.comparison.json" "$snapshot/reference-reproduction/"
expected=$(jq -r .binary_sha256.candidate "$reference/measured/request.json")
actual=$(shasum -a 256 "$snapshot/reference-reproduction/candidate-application" | cut -d ' ' -f 1)
[[ "$expected" == "$actual" ]]
cp /private/tmp/casa-t55-real-density-accounted.p5Medq/initialize-owner.log "$snapshot/reference-reproduction/"
# The sole difference from upstream is table descriptors plus the generated owner manifest.
# No visibility, image-array, or other data payload files are copied.
cp /private/tmp/casa-t55-real-density-accounted.p5Medq/input/refim_point_withline.ms/table.dat "$snapshot/reference-reproduction/input-owner-table.dat"
rustc --version > "$snapshot/rustc-version.txt"
cargo --version > "$snapshot/cargo-version.txt"
git -C /Volumes/home/casatestdata rev-parse HEAD > "$snapshot/casatestdata-revision.txt"
git -C "$repo" rev-parse HEAD > "$snapshot/source-revision.txt"
cp "$0" "$snapshot/capture-evidence.sh"

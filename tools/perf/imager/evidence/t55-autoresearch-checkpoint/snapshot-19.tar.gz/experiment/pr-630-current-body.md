Work issue: #541

## Current WIP checkpoint — 2026-09-11 UTC (post-ADR-0013)

Retained source tip: `1c1f54f7777dcb90611586b5ffceb2c7efafdcc9`, read back on both this draft PR branch `codex/t55-cube-pipeline` and `codex/t55-serial-autoresearch`. Restart evidence: snapshot 19 on the separate evidence branch `codex/t55-autoresearch-checkpoint`. This is a WIP backup, not ticket acceptance or merge approval.

Since the trial-18 checkpoint:
- Retained reader-verified replay-digest binding (`930e919e`): the spill reader's verified payload digest binds the program descriptor without re-hashing; paired parent comparison was 0.9533445209 [0.9109397678, 0.9977232387].
- Accepted ADR-0013 and retained the private run-scoped spill v3 format (`b9db62bd`) with CRC32C instead of per-frame SHA-256: the compiler checksums each frame once, the writer seals a CRC32C header transcript, the reader verifies payload and transcript against the in-memory seal. Bounded-fixture ratio 1.2399 -> 1.1955; paired candidate/parent 0.936815 [0.895951, 0.979542]; guard passed in 165.3 s with 3.12 GiB sampled peak. `docs/adr/0013-non-cryptographic-integrity-for-private-spill.md`.
- Repaired `just arch-check` (`190718f6`): 18 stale migration-matrix baseline digests refreshed and five stale T55 schema/accounting expectations aligned with accepted code; structural suite 18/18 and `just docs-check` pass.
- Reframed the medium-VLA dataset discriminators (`e0b8f390`): dataset identities, block packing, residency and proof-byte totals are recorded JSON evidence instead of asserted goldens; structural invariants and stable selection-derived totals remain asserted. All three ignored probes pass on the mounted 32 GiB dataset. Root cause of the former 7-versus-6 block drift was `42a1a4b53a` per-row multi-domain projection charging, not the selected-row metadata size. ADR-0013's probe note aligned (`1c1f54f7`).
- Current tranche run `b13c5d09af904c0e94263a2cb86c92af` is active at iteration 0 with bounded-fixture baseline 1.1833692208217712 (about 18% slower than CASA; the 0.90 target is unmet).

Large 32 GiB serial gate revalidation (user-authorized; provisional single pairs):
- `wave3-standard-mfs-single-term-heavy-wave2-serial` completed in 600.15 s on a quiet host versus the frozen official CASA anchor 688.996833 s (-12.9%). All five products are inside the unchanged 0.001 normalized-RMS ceiling and RMS-identical to the prior retained products (image 1.925707e-07, residual 3.258093e-07, psf 6.786875e-07, model 5.147635e-07, sumwt exact). Bounded receipts: two MS passes, 4,094,064 rows and 524,040,192 samples per pass, 63 MB peak live source.
- Same-session control at `b2bc3f7cd` ran 741.01 s under identical conditions, so its historical 486.35 s record does not reproduce on today's host; the current tree is 19.0% faster than that control. Absolute anchors are not comparable across host states; paired same-session comparisons are authoritative.
- No new CASA timing was triggered. All full-input numerical/visual/timing, bounded-memory, remaining cube-mode, T57/Metal and final independent contract-review obligations remain open.

## Earlier checkpoint — quota pause, 2026-09-10 UTC (historical)


The controller-validated retained source checkpoint is [`bb47e918348b7dd6ddcc070b7ca0a7d1f3cca3b9`](https://github.com/bglenden/casa-rs/commit/bb47e918348b7dd6ddcc070b7ca0a7d1f3cca3b9), verified on both this draft PR branch `codex/t55-cube-pipeline` and the active branch `codex/t55-serial-autoresearch`. All earlier weighting and bounded cube-lifecycle changes are committed in this lineage. This is a WIP backup, not ticket acceptance or merge approval.

Brian approved repository-wide serial performance experiments preserving CASA-interoperable MS/image formats and scientific behavior. Foreground autoresearch run: `5643a1a0493c4c7d8f1cd2f3ae30c28d`. Fixed metric: geometric native/CASA task-time ratio across five fresh, paired one-worker measurements, with a fresh retained-parent control. Target 0.90, automatic 20-trial tranches and further significant opportunities beyond parity. The fixture remains 256×256, 16 channels, 168,480 rows, Natural/Clark, three major cycles and 19 actual minor iterations. Limits remain 4 GiB native, 8 GiB sampled process group and 600 s per experimental pipeline.

- Initial ratio: 1.7628787405; retained ratio: **1.1790668889**. This is a 33.12% reduction in the measured ratio, not a full-input or absolute historical speedup claim. Latest retained native/CASA medians: 8.143475042 / 6.924885834 s. The bounded fixture remains about 17.9% slower than CASA; parity is not achieved.
- Retained mechanisms: borrowed model/product ndarray reads (`20487d6367`), exact spectral-axis vector reservation (`f4e0947484`), release ThinLTO (`e38e84e418`), shape-aware backing reads (trial 7), shared resampler current borrowing/stable previous slot (`68d0d16bba`), and the bounded problem-bound source-channel spectral cache (`3bd0f90c69`). Earlier normal-read improvement `ec8a292389` is also preserved.
- The latest keep, trial 18, uses contiguous row-slice tile commit with unchanged scalar arithmetic and storage. C/P 0.9770404627, paired 95% interval [0.9590116944, 0.9954081597]: 2.2960% faster than its fresh parent. Both seven-product comparisons at nRMS ≤0.001, metadata/WCS/topology/beam and focused release guards passed. Verify/guard: 242.07 / 114.65 s, peaks 3,464,986,624 / 3,054,731,264 bytes, clean completion. All 51 gridded tests passed, including bitwise overlapping/clipped tile arithmetic. This consumes the one retry of tile indexing after inconclusive trial 13, using row slices instead of multidimensional Zip; no hypothesis allowance is reset.
- Retained trial 17 sets release `codegen-units = 1` while retaining ThinLTO and all numerical/runtime controls. C/P 0.9755542689, paired 95% interval [0.9636441774, 0.9876115624]: 2.4446% faster than its fresh parent. Both seven-product comparisons and scientific metadata/focused release guards passed. Verify/guard: 165.25 / 192.13 s, peaks 532,103,168 / 3,116,040,192 bytes, clean completion. Cold prebuild: 148.15 s, peak 5,986,615,296 bytes within the unchanged limits. Additional affected checks passed: 15 tiled-table tests, 23 C++/Rust image tests, and the explicitly configured CASA-Python degenerate-axis image test. Trial 16's compiler-to-writer payload-checksum reuse was reverted: C/P 0.9888520267 [0.9664415615, 1.0117821601] did not establish a gain; its scientific guard did not run. That implementation is retired.
- Retained trial 15 removes a duplicate payload SHA pass using a version-2 **private temporary** spill header-transcript commitment. Per-frame checksums, original immutable seal, ordering, counts, bounds and exact EOF remain required. C/P 0.9821519780, paired 95% interval [0.9732152497, 0.9911707695]: 1.7848% faster than its fresh parent. All seven products passed nRMS ≤0.001 against CASA and preserved native reference; metadata/WCS/topology/beam checks and affected focused guards passed. Verify/guard: 209.85 / 73.58 s, sampled peaks 2,206,908,416 / 2,697,838,592 bytes, clean completion. The terminal-reader error branch now remains poisoned after footer failure. Thirty spill tests cover actual SHA input work, independently reconstructed transcripts, self-consistent forgeries, metadata/order attacks, versions, empty cases and replay lifecycles; 253 active runtime tests passed, eight ignored.
- Trials 13 and 14 are completed, discarded and visibly reverted: shaped-Zip tile commit and flat-row standard degridding. Neither established a parent-relative improvement; their scientific comparison guard therefore did not run. Trial 13 C/P 0.9815123329 [0.9447233138, 1.0197339745]; trial 14 C/P 0.9977983954 [0.9731135009, 1.0231094698]. Their bitwise arithmetic preflights passed. These candidates are retired.
- Trial-12 focused library preflight: 220 reconstruction and 248 runtime tests passed (17 and 8 existing ignored). The broader `compile_plan_run` suite has 88 failures / 91 passes, reproduced as exactly the same failing test-name set on the isolated parent. Most fail at pre-existing `MissingPointingQueryDomain`; legacy workspace assertions also remain. No tests were weakened or called green. A shared-target build-fingerprint setup failure was corrected by forcing the current crate rebuild; the three directly affected production-weighting plan tests then passed.

The current bounded cube lifecycle permits the development CLEAN runs under the fixed memory ceiling; the earlier all-channel admission rejection below is historical. **A complete full-input serial run, matched full-input CASA numerical/visual/timing acceptance, full bounded-memory acceptance, and the remaining T55/T57 obligations are still outstanding.** Worker scaling is not being used to conceal the serial gap. The 0.90 target is not achieved; no scope has been deferred.

### Quota stop and durable restart requirement

Brian added an account-wide weekly quota checkpoint: check the 10,080-minute window before every new trial and during long reasoning intervals; at **15% remaining or below**, start no new experiments, finish in-flight work at a safe boundary, publish a durable restart checkpoint, and pause pending explicit resumption. The checkpoint was reached during trial 18, which then completed. **15% remaining** (85% used; reset Unix 1789435318). No trial 19 was started or selected. This is not exact task billing and is not scientific completion.

Brian explicitly authorized pushing in-progress source and essential run/evidence state to the existing project remote. Source is verified above. The [durable restart checkpoint through trial 18](https://github.com/bglenden/casa-rs/tree/ba6b74972d73d85b973144483623475e5663f75f/tools/perf/imager/evidence/t55-autoresearch-checkpoint) is published on the separate evidence branch `codex/t55-autoresearch-checkpoint`. Its 20,823,603-byte archive preserves configuration/events, commands/results, rejected hypotheses/retry state, retained/reference binaries, remaining acceptance and exact restoration instructions without changing the active controller's HEAD or immutable state. Internal file and archive checksums passed; source and evidence remote identities were read back. No visibility or image-array payload is redistributed. The data reconstruction recipe plus the small generated owner-metadata file was tested to reproduce the frozen input hash. Snapshot 14 remains historical, not the restart tip. No merge, release, cleanup or worktree deletion is authorized.

The [bounded GPT-6 Pro (Power 5) consultation](https://chatgpt.com/c/6aa1e814-97cc-83e8-b963-e8ee5b9c7432) supported trial 15 under correct, collision-resistant SHA-256 and the original trusted seal. It independently inspected pinned owners/consumers/tests, not local data or execution. The local tests address its integrity and lifecycle concerns. This is not final T55 contract review.

The older ignored medium-VLA construction discriminator stops before spill construction at captured blocks 7 versus expected 6. Git provenance identifies the intervening 65-to-73-byte selected-row metadata change. One bounded test-only probe independently streamed the current artifact and verified v2 digest `babf4d4db5b8ad181543460ba7a74f923a461dd7b38c70b3645c81195b717dd9`; only that format-dependent golden was migrated. Its reconstructed v1 digest differs from the historical v1 golden, so historical byte identity is not claimed. Source-layout, weighting, coverage, normal-state and logical-artifact expectations were not blindly refreshed; the old diagnostic remains non-green. Temporary migration instrumentation was removed and preserved with its logs. Full-scope acceptance remains outstanding.

The repository is clean and controller-consistent at iteration 18; no experimental process remains. Experiments are paused pending Brian's explicit resumption. The immutable controller and unfinished Goal still report active: available Goal tools cannot set paused, and app control was denied. Do not bypass that denial or fake completion/blocking; Brian must pause the Goal in the app if needed. Neither automatic continuation nor quota reset authorizes another trial. Source and essential restart evidence are durable through trial 18, with complete rejected/retry history and unchanged acceptance obligations.

## Earlier checkpoints and full-scope obligations (historical evidence)

### Earlier cube-first state

Committed checkpoint: `b7c482f72b7d8375dc86c97f96bc12248c734f15`; committed production checkpoint: `3ecbac5593fbb7fbba450365270c412b1b35456e`. The additional per-channel weighting correction is uncommitted WIP, with bounded development evidence below; it is not full ticket acceptance.

This draft is the canonical current implementation/evidence summary for the approved [T55/T57 cube-first amendment](https://github.com/bglenden/casa-rs/issues/486#issuecomment-5588851986), linked from #486, #541 and #543. All original T55/T57 scope, frozen #449 rows, #625 serial science acceptance, and the single final independent contract review remain required. The end-to-end 10x target applies to relatively large datasets, approximately 32 GB and larger, not the small development fixture. No partial merge or scope deferral is approved.

Natural-weighting serial Clark cube products pass all nine unchanged CASA checks. All seven products across every output channel were visually checked. Real W1/W2/W3 executions agree exactly on scientific arrays, image metadata and non-affine cycle evidence. The original channel-edge weight discrepancy and the test harness's unmatched restoration cutoff are resolved.

The matched per-channel Briggs(0.5) development comparison now passes all nine unchanged CASA checks. All six real Natural/Briggs W1/W2/W3 executions pass and agree exactly on scientific arrays, image metadata and non-affine cycle evidence. All seven products across all four channels were visually inspected for both weighting settings. Briggs normalized RMS differences are PSF 0.000162687, residual 0.000162252, image 0.000119572 and sum weights 0.000007986, below the unchanged 0.001 ceiling. Beam checks pass; PB and mask differences are zero. This small-fixture result is not large-data, speed or complete T55/T57 acceptance.

Astra XHigh localized the missing native endpoint weight; the canonical unflagged shifted-channel regression went red before the correction and is now green. Completed GPT-6 Pro (Power 5) consultation and locally verified pinned CASA/casacore source distinguish three stages: raw native-weight resampling into nominal padded density planes, one native scalar per mapped density plane, and nearest-native weight transfer alongside independently linear data interpolation. The existing owners now implement those stages using one payload-independent bounded row cursor and one shared fused/replay scalar calculation. Nominal CASA density extent is preserved rather than enlarged to hide missing support. No epsilon, flag substitution, tolerance relaxation or persistence change was used.

The consultation independently inspected the pinned Rust source but could not retrieve the pinned CASA source; supplied excerpts were verified locally. No new instrumented installed-CASA intermediate-density trace is claimed. The first real comparison wrapper failed final bookkeeping because it compared different source-key sets; an explicit reconciliation verified every saved source identity, unchanged original input, all six native results and both nine-check comparisons. That failed receipt remains retained. After the accounting and internal-identity changes, the final candidate completed the full six-case matrix and both nine-check comparisons again with a clean process-guard exit and verified unchanged source/input identities.

The application binding currently covers regular, multi-channel, linearly interpolated cubes. Moving-source, non-linear and single-output-channel variants are unfinished work, not approved exclusions. Frozen layout metadata and both raw-density/output-sum accumulator classes are charged through generation and replay; the new metadata has also been added to the cross-plan reservation. Further edge/metadata and full-scope acceptance remain required.

## Full-input timing checkpoint — blocked before execution

The user has reprioritized matched timing on the complete large input before further mode-coverage expansion. The small development fixture is not speed evidence. A new opt-in production-application timing test compiles and passes focused release Clippy; it preserves the complete input selection and explicit resource ceilings.

The full-cube CLEAN attempt was rejected during memory admission before visibility processing or product publication. The same request with existing allocation diagnostics confirmed the rejection. All worker candidates were infeasible: the dominant demands are all-channel operator grids and primitive outputs, not worker-private minor-cycle scratch. Natural weighting is not the large density allocation in this case. Current CLEAN planning bypasses the bounded channel-major initial path used without a minor cycle. This is a cube-residency prerequisite, not a measured runtime or a speed regression result.

No CASA timing, completed full-data native run, or speedup is claimed. No input reduction, memory-limit increase, production implementation change, or acceptance relaxation was made to force a result. Setup-only failures and both fast admission results remain retained locally. A bounded cube-memory correction needs an implementation decision before the requested matched pair can proceed. All remaining T55/T57 scope below remains required.

## Implemented ownership and preserved contracts

- Reconstruction owns channel-local Högbom/Clark prepared work and ordered commit. Runtime composes complete owner/worker/replay-window candidates before admission. Full-plane resident CLEAN, common thresholds and deterministic collection remain intact.
- Selected-row spectral geometry uses the first two selected native centres after prepared frame conversion. Separate prediction and accumulation roles preserve CASA's forward law, edge eligibility and image-frequency evaluation without fallback to unselected channels or channel-width guesses.
- The shared frequency conversion now mirrors CASA's scalar sidereal-time extraction. Its regression and direct reference checks preserve channel-edge coverage without an epsilon or tolerance change.
- Publication storage metadata is compiler-owned. Signed PB limits, numerical support, CLEAN search support and stored masks remain distinct; sinks serialize sealed metadata. CASA-interoperable persistence is unchanged.
- Production source compilation uses checked fixed-capacity arenas and bounded native prediction banks. Ordered compensated reduction and continuous framing preserve term order. No alternate production compiler remains.
- Transient compiler storage and retained artifact metadata are accounted separately. Runtime transfers existing admitted memory/storage permits only after successful work, fences and scientific sealing. Shared backing retains ownership across replay and releases at final drop; no release/reacquire gap or unaccounted alias is introduced.
- Disjoint compiler/minor-cycle workspaces share one admitted slot while retained metadata remains separately charged. The original admission and memory-floor assertions are unchanged.
- In-scope non-persistent ownership changes are approved. This does not authorize science/precision changes, CASA-persistence changes, scope reduction, relaxed resource limits, release or cleanup.

## Focused evidence at the committed checkpoints

Raw Cargo checks use `CARGO_INCREMENTAL=0`. Green results below belong to their committed checkpoints and do not accept the later per-channel candidate.

| Gate | Recorded result |
| --- | --- |
| `casa-types` library tests | 169 passed, including the scalar sidereal-time regression |
| Frequency C++ interoperability | 21 passed, one existing ignored |
| `casa-ms` spectral selection | 53 passed |
| Runtime execution and authority | 61 execution tests and 32 resource-authority tests passed |
| T55 admission gates | Both unchanged gates passed, including the original tight-memory fixture |
| Shared parallel replay | Six focused tests passed |
| Managed spill and receipt checks | 23 spill tests; 10 receipt tests passed, one existing ignored |
| Reconstruction retained compilation | 50 gridded tests plus shared-catalog and empty-frame binding checks passed |
| Application integration suite | 43 passed, one existing ignored, before the per-channel candidate |
| Affected checkpoint lint/format/docs checks | Passed at the recorded committed checkpoints |
| Matched Natural CASA comparison | All seven products and both beam checks passed unchanged tolerances; every channel visually inspected |
| Real worker determinism | All six original Natural/global-density-Briggs worker cases passed; this is not matched per-channel Briggs acceptance |
| Current per-channel candidate | Shifted canonical regression passes; all six matched real Natural/per-channel-Briggs worker cases and both nine-check CASA comparisons pass |
| Current weighting and spectral tests | 28 weighting tests and 14 spectral tests pass, including analytic native scalar, fused/replay identity, nominal extent, descending ties and independent flags |
| Current affected lint | Release Clippy for model, MS, reconstruction, runtime and application, all targets with warnings denied, passes |
| Current application and admission checks | All four canonical T55 cube application tests and both unchanged worker/memory-floor admission gates pass |
| Current internal identity contracts | All 35 compiled-problem and seven measurement-equation contract tests pass with the explicitly versioned cube-law encoding |

Earlier unaffected focused evidence remains retained for reconstruction units, weighting integration, bounded multi-frame major cycles, Taylor/joint replay, spectral sampling, publication products and compiled-problem contracts. Detailed commands, source identities, unsuccessful attempts and diagnostic artifacts are retained locally. This public summary intentionally omits workstation paths and detailed operational metadata.

The new field requires internal scientific identity migrations: compiled problem v25, science basis v4, prepared-artifact dependencies v2 and weighting commitment v5. Pinned digest assertions were recaptured after auditing those encoders; no identity assertion was removed. A stale pre-existing problem-version assertion in the directly affected measurement-equation test was migrated as well. These are internal identity changes, not CASA-interoperable format changes.

## Known failures and boundaries

- `just arch-check` is not green: stale migration/source identities and an existing paired-model trace failure were reproduced on the committed parent. No blind baseline refresh was made.
- Earlier complete-file fixture failures were reproduced on untouched source and are not represented as green. Tests were not weakened, deleted or ignored to obtain acceptance.
- Existing process-global mixed-mode storage-profile incompatibility remains an adjacent limitation. Test isolation does not constitute a production fix.
- Failed scientific runs and isolated kernel measurements are not end-to-end speed evidence.
- The current F64 compensated Numerics Contract remains binding. The Apple GPU compiler's native-double limitation is established, but the operation-scoped mixed-precision question is unanswered. No production F32 amendment or CPU fallback is authorized.

## Next acceptance boundary

After the user-directed full-input timing prerequisite is resolved, complete remaining cube-mode bindings and focused edge/metadata/resource checks; retain the locally verified source semantics and diagnostic history, and extend the proven linear-cube owner correction to the full approved acceptance matrix. Use a first-intermediate CASA trace for any remaining scientific discrepancy, and reuse unchanged CASA references. Preserve accumulated hypothesis/escalation history and the user's bounded execution checkpoints. No independent final contract review has yet accepted this candidate.

Representative/frozen #449 and #625 obligations, measured real input/compute overlap, complete T55/T57 resource/failure and performance gates, qualified actual GPU work, and the large-dataset 10x evidence remain required. Private framed-artifact identity goldens in the opt-in larger compiler probe require validated recapture before being claimed current. Consolidate the single independent contract review only at full ticket acceptance. No merge, release, cleanup or branch/worktree deletion has occurred.


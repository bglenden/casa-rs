import json
import os
from pathlib import Path
import sys

REPO = Path('/Users/brianglendenning/.codex/worktrees/5d43/casa-rs')
sys.path.insert(0, str(REPO / 'tools/perf/imager'))
from perf_harness import t51_pair_guard

t51_pair_guard.RSS_BYTES = 8 << 30
prefix = Path(sys.argv[1])
environment = os.environ.copy()
environment.update(CARGO_INCREMENTAL='0', PYTHONDONTWRITEBYTECODE='1')
with prefix.with_suffix('.log').open('x') as log:
    receipt = t51_pair_guard.run_pair_pipeline(
        sys.argv[2:], cwd=REPO, environment=environment, log=log, wall_seconds=600)
prefix.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
sys.exit(0 if receipt['complete'] else 1)

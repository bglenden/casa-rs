# T55 bounded ChannelLocal lifecycle: implementation brief

## Current quota pause — 2026-09-10 00:32 UTC

Experiments are paused pending Brian's explicit resumption after the weekly
allowance reached 15% remaining (85% used; 10080-minute window; reset Unix
1789435318). No trial 19 was started. Trial 18 completed and was retained as
`bb47e918348b7dd6ddcc070b7ca0a7d1f3cca3b9`: direct row-slice tile commit,
C/P 0.9770404627, 95% interval [0.9590116944, 0.9954081597], a 2.2960%
parent-relative gain. Native/CASA ratio is 1.1790668889, medians
8.143475042 / 6.924885834 s. The ratio is 33.1170% below this campaign's
1.7628787405 baseline but still 17.9% above CASA; this is bounded-fixture
evidence, not full-input performance acceptance.

Both seven-product nRMS <=0.001 comparisons, metadata/WCS/topology/beam and
focused release guards passed. Verify/guard completed in 242.07 / 114.65 s,
sampled peaks 3,464,986,624 / 3,054,731,264 bytes. The preflight passed 51
gridded tests, including bitwise scalar-reference arithmetic. Trial 18 consumed
the one retry of tile-commit indexing after trial 13; no allowance is reset.
Trial 17's release-codegen change and trial 15's private spill v2 also remain.

Run `5643a1a0493c4c7d8f1cd2f3ae30c28d` validates clean/consistent at iteration
18 on `codex/t55-serial-autoresearch`; no experiment process remains. Its event
stream still says active because the numeric goal is unfinished. Goal tools do
not expose pause, and app control was denied; do not bypass that denial or mark
the goal complete/blocked to simulate a pause. Brian must pause the Goal in the
app if it remains active. Automatic continuation or a quota reset is not
permission for another experiment. Preserve all state until explicit resumption.

The source checkpoint is pushed and read back at the exact SHA on both existing
authorized origin branches. Snapshot 18 is being prepared on `codex/t55-autoresearch-checkpoint`
with frozen controller/configuration, all trial evidence and the retained/native
reference binaries. PR #630 remains the canonical public summary; #541/#543/#486
link to it. All full-input, bounded-memory, scientific/visual/timing, remaining
mode and final contract-review obligations remain unchanged. No merge, release,
cleanup, worktree deletion, or acceptance waiver is included.

On explicit resumption: verify remote/source and snapshot hashes, restore exact
paths only if necessary using the evidence README, validate controller status,
read the full rejected-candidate history, refresh usage, then inspect the retained
profile before choosing a new distinct candidate. No trial 19 is selected.

## Campaign record

Status: on 2026-09-09 at 19:25 UTC the user approved a new foreground
codex-autoresearch campaign across the entire repository, preserving CASA MS,
image, and other persistent interoperability. Metric: five freshly paired
one-worker native/CASA end-to-end timings, geometric native/CASA ratio, lower
is better. First target 0.90; automatically continue in 20-trial batches and
successive 5% improvement tranches while evidence-backed significant candidates
remain. Parity alone is not the stopping condition. Full-input correctness,
serial timing, and bounded-memory acceptance remain required before closeout;
intermediate results do not satisfy them. No push, merge, release, or cleanup.

Preserve the 256x256, 16-channel, 168480-row one-worker fixture, 4 GiB native /
8 GiB sampled-process bounds and 600 s command limit. Freeze all effective CASA
parameters, timing and comparison controls. A keep requires improved matched
CASA ratio plus paired parent/candidate 95% log-ratio upper bound below 1, seven
products at nRMS <= 0.001 versus CASA and preserved native reference, metadata /
WCS / topology / beam guards, and affected focused tests and interoperability.
Before any unattended overnight execution, agree a time or spending checkpoint.

Quota checkpoint added by Brian on 2026-09-09 via his coordinating task:
read live account-wide weekly Codex usage now, before each new trial, and during
long reasoning intervals. Use the 10080-minute window; remaining = 100 - used.
At 15% remaining or below, start no new experiments, bring in-flight work to a
safe recorded boundary, publish a durable restart checkpoint, then pause for
explicit resumption. A little overshoot is allowed; missing usage is unknown,
not zero consumption. The first refreshed reading is 20% remaining (80% used,
weekly reset Unix 1789435318). This is a pause, not scientific completion.

Brian now explicitly authorizes checkpointing and pushing in-progress project
code to the existing `origin` GitHub remote. Preserve controller Git/state
invariants; verify the remote branch and exact commit. Preserve essential run
state, evidence, rejected hypotheses/retry state and restart commands remotely,
not solely local paths or conversation. Update the already tied issues/PRs and
this current work record with retained gains, latest trial, acceptance gaps,
repo/branch/full SHA/run identity and quota reading. Exclude secrets, personal
data and non-public datasets. No merge, release, cleanup or worktree deletion.
This authorization supersedes the earlier no-push limit only for durable WIP
checkpointing; all scientific, resource and other stop conditions remain.

Current setup commit: `fe6a4cbd76ac22ca289958da5682da79cf3bfd5c`, retaining the
normal-read improvement `ec8a292389`. Driver and tests:
`tools/perf/imager/t55_serial_autoresearch.py` and
`tools/perf/imager/test_t55_serial_autoresearch.py` (7 tests passed).
Artifacts/configuration: `/private/tmp/casa-t55-serial-ratio.OnKOSr`.
Verify/guard: `CASA_RS_T55_AUTORESEARCH_ROOT=/private/tmp/casa-t55-serial-ratio.OnKOSr PYTHONDONTWRITEBYTECODE=1 python3 tools/perf/imager/t55_serial_autoresearch.py verify`
(replace final argument with `guard`). CASA preflight passed at 19:42 UTC,
3 major cycles / 19 minor iterations, 8.55 s task. Stale copied `table.lock`
files caused the initial CASA selectData assertion; preserved them separately
and ran with the configured CASA interpreter outside the sandbox. Input data
tree remained d62a5398f825f6a96510bd64516ab0ad731ce73a75201230d995b4df965be8f0.
Setup failures are not performance trials. The earlier closed controller was
explicitly archived to `autoresearch-results/archive/20260909-192618`; its
history was not rewritten. New initialization and experiment evidence follow
the controller's validated state and append-only log.

Initialization passed at 19:46:35 UTC: run `5643a1a0493c4c7d8f1cd2f3ae30c28d`,
baseline ratio 1.7628787405420967 (approximate paired 95% interval 1.65858 to
1.87374), native/CASA medians 15.519841625 / 8.868953250 seconds. All seven
products passed the native and CASA comparisons and the focused baseline
tests passed. Verify/guard pipelines took 166.19 / 42.44 seconds, with sampled
process peaks 485310464 / 1315553280 bytes. A matching foreground Goal was
created. Trial 1 is controller-owned commit `215f5b1becb8556d5e4f623c797425e44df04eab`:
reserve exact centre/boundary vector capacity in `channel_local_terms`, removing
reallocation without changing interpolation. Its 14 spectral-sampling tests,
formatting and whitespace checks passed before timing. The controller discarded
and reverted it at 19:54:46 UTC: paired C/P ratio 0.910884 but 95% interval
[0.827807, 1.002297] did not establish an improvement; native/CASA ratio 1.721110.
The scientific guard did not run after that timing rejection.

Trial 2 retained at 20:06:23 UTC: `20487d6367eb8584676f1d066829790bd4393043`,
borrowing ndarray iterators in model and product backing reads. Paired C/P ratio
0.9172570201 (8.2743% gain), 95% interval [0.8850425952, 0.9506440091]. The
matched native/CASA ratio is 1.5591349535; medians 12.575619083 / 7.754086250 s.
All seven products passed against both CASA and preserved native reference,
metadata/WCS/topology/beam guards passed, and all 248 active runtime lib tests
passed (8 resource-specific tests remain ignored). New tests cover canonical
four-axis product-window ordering and rejection of nonfinite / unsupported model
payloads. The wider runtime check exposed an older T55 fixture mismatch: commit
56d027 had doubled pending-delta storage but retained the former 2 GiB assertion.
The retained trial repairs that expectation to model samples plus two delta-term
buffers; it does not change production planning or weaken the admission test.
The array-traversal change leaves formats, arithmetic and resource accounting
unchanged. The foreground loop remains active; target and full-input acceptance
are not achieved. A bounded profile of the retained binary is under
`/private/tmp/casa-t55-serial-ratio.OnKOSr/profile-after-trial-2`.

Supporting read-only check: SHA-256 already executes ARM SHA instructions in the
profiled release binary, so no missing-hardware-acceleration candidate is retained.
The idle browser-control session was reset between trials after its runtime was
observed consuming CPU; browser tabs were not closed. No host indexing or other
user processes were altered. Paired parent and CASA runs are fresh for each trial.

Trial 3, the single evidence-producing retry of exact axis-vector reservation,
was retained at 20:15:28 UTC as `f4e0947484dbc07b9e6040cdb7a4b89479f9d08f`.
Paired C/P ratio 0.9581996512 (4.1800% gain), 95% interval
[0.9391197948, 0.9776671481]; native/CASA ratio 1.5494358333, medians
10.711158750 / 6.970393417 s. All seven products versus both references,
scientific metadata and focused guards passed. The first trial's inconclusive
result is preserved, not reinterpreted as a keep. The fresh profile and removal
of the busy idle browser-control session supported this one bounded retry.
Trial 4 was discarded at 20:27:28 UTC: indexed, allocation-free spectral axes
passed 15 Rust spectral tests, 14 compiled-geometry tests, and 17 release
spectral tests including casacore oracles. Its C/P ratio was 1.0009820568,
95% interval [0.9918134294, 1.0102354418], effectively tied with the parent.
The paired timing guard rejected it before product comparisons. Trial commit
`968e137e40f590454b37a82c8228e52b4ca39de6` was controller-reverted by
`ff9a292a2a1c9bb50acdc9bed0d78cdefe3b0eb5`; retained ratio remains 1.5494358333.
The on-demand implementation is retired; no timing win is claimed from its
lower allocation count. Next distinct candidate: release ThinLTO only, allowing
cross-crate optimization without changing source semantics or persistent data.
Precompile within the existing 600-second / 8-GiB limits before paired timing.

Trial 5 retained at 20:35:49 UTC as `e38e84e4186f568b33b2e481d8d452ee3674ab02`:
release `lto = "thin"`, with codegen units and floating-point semantics unchanged.
Cold application build: 114.69 s, sampled process peak 4,208,640,000 bytes,
within the approved limits. C/P ratio 0.9765971111 (2.3403% gain), 95% interval
[0.9658642328, 0.9874492552]; native/CASA ratio 1.5268511176, medians
10.455950916 / 6.818825750 s. All seven products against both references and
the focused scientific guard passed. Additional focused table/image C++
interoperability checks precede profiling the retained binary for the next
source-level trial. Full-input acceptance and the 0.90 target remain open.

ThinLTO follow-through: 15 tiled table cross-matrix/endian tests and 23 C++/Rust
image tests passed. The optional CASA-Python image test was rerun explicitly
with CASA 6.7.6.14 (rather than relying on interpreter auto-discovery) and passed.
The combined C++ pipeline took 107.04 s, peak 922,419,200 bytes; the explicit
CASA image test took 10.36 s, peak 262,684,672 bytes. A fresh retained-binary
profile is in `profile-after-trial-5` (12.01 s pipeline, peak 504,463,360 bytes).

Trial 6 was discarded at 20:49:29 UTC. Direct selected-MS flag/weight column
reads passed 61 focused tests (2 pre-existing resource-specific ignores), but
C/P ratio 0.9981778825 with 95% interval [0.9816385271, 1.0149959049] did not
establish a gain. The timing guard stopped before product/interop comparisons.
Trial `ab42b0d1d146aafae130f1db7b217061e4b541f5` was controller-reverted by
`6a547f3a4699f4c9507e5b8898156d1690c1e8a4`; retained ratio stays 1.5268511176.
Trial 7 retained at 20:59:08 UTC as `7ed1f2008d4d44e56c31f256402356e62bf40026`:
dense model slices and shape-aware product assignment improved paired time by
3.2141%, C/P 0.9678592675 (95% interval [0.9406890973, 0.9958142008]).
Native/CASA medians were 10.269706 / 6.927734 s; geometric ratio 1.4742078442.
All seven products passed against both references at nRMS <= 0.001, along with
scientific metadata, paired timing, and focused guards. The affected runtime
preflight passed all 248 active tests (8 existing resource-specific ignores),
including four-axis order and degenerate-axis storage checks. Peak preflight
RSS was 1,511,047,168 bytes in 173.54 s. No extra materialization or persistence
change. The remaining native initial stage still takes about 6.6 s of the 10.3 s
total.

Trial 8 was controller-reverted at 21:09:06 UTC: borrowing the selected sample
in each synchronous resampling callback improved every pair, but C/P
0.9647454193 had interval [0.9216290442, 1.0098788986], so the timing guard did
not establish improvement and stopped before product comparisons. Candidate
`fadd9bd91f63bab401c33fee1042f4e97fdbdd9b`, revert
`a93e6cd1431a2e9e1b7144197502341f915eebd1`. All 214 active reconstruction
tests passed beforehand (17 existing ignores), 71.41 s and peak 1,322,188,800
bytes. Unlike the retired pending.take experiment, this removes only output
selected-sample clones; it does not change pending-row transitions. Because all
five pairs improved but timing was inconclusive, trial 9 used its one permitted
fresh-pair retry under unchanged controls. It too was discarded at 21:14:37 UTC:
C/P 0.9807358713, interval [0.9560365965, 1.0060732537], native/CASA ratio
1.4798080340. Scientific guard was not run because the metric failed first.
Trial `7e3d249b16280201458117d41ff66f47cdd3df09` was reverted by
`cd1d73643f013fc4151de948b66702d98aa15d33`. Borrowed output-selected samples
are now retired; no further unchanged retry. The next candidate batches fixed
channel/correlation canonical byte chunks into single hash updates, preserving
the exact schema-9 bytes and identity fixture.

Audit correction during trial 10: archived campaign iteration 4 already tried
the borrowed selected-sample metadata candidate. Trials 8/9 repeated that
retired candidate and should not have been rerun. All trial/revert evidence is
preserved, no result was promoted, and no retry allowance is reset. Future
selection checks the full archived rejection list, not just the latest tranche.

Trial 10 was discarded at 21:23:46 UTC: batching canonical channel/correlation
hash updates was flat, C/P 1.0001189314 (95% interval [0.9825075302,
1.0180460161]), Rust/CASA ratio 1.5154034888. Candidate
`ac61004aacf6eb3a9dd4efe5b1c1fc2784bc96d1` was reverted by
`e9693bbafc1af93ba5b7d41615d8828eedf3e4cf`. The 93 model unit/integration
tests and unchanged schema-9 digest passed, but the metric failed before the
scientific guard. Candidate retired; hash-call reduction alone is not a win.
One initial test-wrapper exit-time descendant warning was preserved and the
bounded setup retry completed cleanly (61.95 s, peak 426,573,824 bytes).

Trial 11 candidate: eliminate large inline native-group moves with a borrowed
current input and one reusable boxed previous group in the shared resampler.
This is distinct from pending.take alone, selected-result borrowing, and
prediction/atom reuse. Preserve current-group retention after interpolation or
emit failure, block independence, row ordering and finish errors. Account the
boxed pointee, retained sample/spectral/projection storage, and all simultaneous
current/previous/resampled value buffers in compiler and complete-data bounds;
reuse the existing forward-workspace reservation for complete-data row state.
Preflight passed 216 reconstruction and 248 runtime active release unit tests,
including stable-owner/buffer reuse, source-buffer mutation, row transitions,
incomplete finish and interpolation/emission error-state checks. Existing ignores
remain 17 and 8. Both new native-row reservation and existing slab/halo integration
checks passed. The ownership ledger includes temporary old/new sample capacity
overlap during growth. Unit build/test pipeline: 239.66 s, sampled peak
1,726,955,520 bytes; reservation integration build/test: 192.00 s, peak
1,242,611,712 bytes. Formatting and whitespace checks passed.
The first preflight failed only on a test enum spelling, corrected before this
run. The retry guardian reported exit_code 0, complete true; its outer one-off
wrapper erroneously expected a string stop_reason instead of null and returned
1. The actual test success and guard receipt are retained; subsequent wrappers
use the guardian's complete field. No controller state was changed manually.
Trial 11 retained at 21:55 UTC as `68d0d16bba89ae20816608dd13ca39e1b9797e66`:
C/P ratio 0.9212920481 (7.8708% improvement), 95% interval
[0.9109070195, 0.9317954739]; native/CASA ratio 1.3416194825. All seven
products passed versus both CASA and the native reference at nRMS <= 0.001,
along with scientific metadata, the paired guard and focused tests. The exact
measurement and receipts are under the commit directory in the artifact root.
The gap is reduced, not closed; full-input acceptance remains outstanding.
The retained-build profile completed in 10.67 s, sampled peak 502,497,280 bytes,
under `profile-after-trial-11`. Trial 11 medians were native 9.244057125 s and
CASA 6.901568083 s. The new profile still attributes 273 samples to cache misses
calling spectral compilation, including 254 in canonical stencil compilation;
the last-entry cache misses again at each native-channel traversal in a new row.

Trial 12 candidate: replace that last-entry cache with a reconstruction-owned,
problem-bound spectral cache. Its direct-mapped slot count is the largest
selected source-window channel count, independent of row count and sparse
channel-id magnitude. The full existing MS/field/SPW/channel/native/output
interval key must match; collisions or changed intervals use the unchanged
canonical stencil compiler. Reserve exact slot payload, compiler frequency-axis
scratch and conservative spilled-contribution/miss overlap in one dedicated weighting allocation,
claimed by source/generation/replay and retired at the terminal replay fence.
No persistent format, weighting arithmetic, flag validity, or stencil law change.
The pre-cutover `casa-ms/src/spectral_selection.rs` prepared channel contribution
tables were inspected; no old execution path is restored. This is distinct from
retired on-demand output-axis evaluation and exact-vector reservation trials.

Initial type-check selected all integration targets and exposed unchanged
`mtmfs_clean_oracle.rs` fixture calls to removed `SealedMember::payload/validity`
and an older two-argument seal call (also present at retained HEAD). Production
cache/runtime code type-checked before that unrelated fixture failure. Do not
repair that unrelated suite here; run the directly affected library tests and
`compile_plan_run` integration gates. Artifact: `trial-12-check.log`, 48.06 s,
sampled peak 947,175,424 bytes. No performance result yet.

Trial 12 focused library preflight passed 220 reconstruction and 248 runtime
tests (17 and 8 existing ignores), including all four new cache tests, in
234.52 s with sampled peak 1,513,160,704 bytes under the 600 s / 8 GiB guard.
Artifact: `trial-12-unit-tests-final.log`. Earlier setup runs are preserved:
one caught five unmigrated test-only cache constructors; the next passed tests
but failed the guard's exit-time descendant check and is not clean resource
evidence. The final run has `complete: true` and no stop reason. The subsequent
lifetime audit removed a shadowed second cache in the two-pass weighting helper;
both passes reuse one problem-bound cache. The full `compile_plan_run` target
was the next bounded integration preflight. It completed test execution in
211.68 s, sampled peak 1,241,808,896 bytes, with 91 passes and 88 failures.
An isolated `git archive` of retained HEAD at
`/private/tmp/casa-t55-trial12-parent.be4PTT` reproduced exactly the same
88 failing test names and 91 passes in 303.24 s, sampled peak 1,270,611,968
bytes (`trial-12-parent-integration.log`). Most affected execution fixtures
stop at `MissingPointingQueryDomain`; other unchanged failures include old
minor-cycle memory expectations. These failures are not clean gate evidence.
Both weighting allocation-count fixtures were already stale at the parent
(actual 4, expected 5); incrementing their expectations had repeated the stale
offset (actual 5, expected 6). Restored the correct candidate expectation 5;
the new cache-specific identity, byte and lifetime assertions remain in place.
The scoped `production_weighting_fragment_` preflight passed all three tests
in 205.49 s, sampled peak 1,236,205,568 bytes, complete resource guard. Artifact:
`trial-12-cache-plan-tests-retry.log`. Its first build saw the parent artifact
in Cargo's shared cache; touching the candidate reconstruction library entry
forced the correct crate rebuild, with no content change or source repair.
The new spectral-cycle cache reservation checks had already passed in the
full candidate run; production code is unchanged since that run.
The parent comparison is diagnostic only and does not change the candidate or
controller history.

Trial 12 retained at 22:44 UTC as `3bd0f90c692ab5139fc4586ba90dcf6d608c9f44`:
C/P ratio 0.9514819838 (4.8518% improvement), paired 95% interval
[0.9400615186, 0.9630411920]; native/CASA ratio 1.2782518014. Native/CASA
medians were 8.837087083 / 6.921269333 s. All seven products versus both CASA
and the preserved native reference passed nRMS <= 0.001, scientific metadata
and affected focused guards passed. Guard pipeline: 72.85 s, sampled peak
2,864,463,872 bytes, complete with no stop reason. The broad integration
baseline failures remain recorded above, not relabelled as a passing suite.
Full-input acceptance and the 0.90 target remain open.

Trial 13 candidate: replace repeated two-dimensional indexing in
`GriddedNormalOperatorApply::commit_two_domain` with a shaped `ndarray::Zip`
traversal owned by the tile accumulator. Preserve canonical task/plane order,
zero-value skipping, and the exact current contribution/compensation arithmetic.
The retained-build profile attributes 374 exclusive samples to this commit
loop. The pre-cutover gridder's paired planned-grid update uses direct storage
access, supporting the indexing-cost hypothesis without restoring its fallback
route. Add bitwise scalar-reference coverage for overlapping, clipped tiles;
run focused reconstruction tests, then the unchanged controller metric/guard.
No memory growth, storage-format change, checksum weakening, or new execution
mode is included.

Trial 13 gridded-operator preflight passed in 68.18 s, sampled peak
1,326,071,808 bytes, complete 600 s / 8 GiB guard. Artifact:
`trial-13-gridded-tests.log`; exact scalar-reference tile arithmetic passed.
Formatting and whitespace checks passed. Proceed to the controller-owned trial.

Trial 13 discarded and controller-reverted (`9bffdf8d352c161b388727379737d0164f8104d4`):
native/CASA ratio 1.2885524209, C/P ratio 0.9815123329 with paired 95% interval
[0.9447233138, 1.0197339745]. No established speedup; scientific guard was not
run after the timing rejection. Retire shaped-Zip tile commit. The controller
validates active iteration 13, clean and consistent, retained ratio 1.2782518014.

Trial 14 candidate: use contiguous row slices in `StandardConvolution::degrid`,
mirroring the existing compensated-grid traversal. The measured degrid path
accounts for 227 samples in the retained-build profile; pre-cutover planned
degridding also uses direct storage. Preserve x-then-y traversal and the exact
complex multiply/add sequence, with no allocations, reassociation, format or
runtime change. Add a bitwise scalar-reference test over rectangular grid
edges, every fractional x tap index with reversed y index, signed zero and
cancellation-sensitive finite values. Run spectral tests before the fixed
five-pair controller metric and scientific guard.

Trial 14 spectral preflight passed 56 tests (two existing ignored), 21.93 s,
sampled peak 1,483,915,264 bytes, complete 600 s / 8 GiB guard. The controller
discarded trial `1cccc12cc6ab1809988a89a37d8cd4c3b1d5490b` and reverted it as
`eae932ad832cbc176adae6ac938cf89f49b214d8`. C/P ratio 0.9977983954, paired 95%
interval [0.9731135009, 1.0231094698]; native/CASA ratio 1.3522557779, medians
9.566420292 / 7.064553417 s. No established speedup, so the scientific guard
did not run. Retire the flat-row degrid candidate. Validated controller status
is clean/consistent, active iteration 14, retained ratio 1.2782518014.
Quota rechecked before considering another trial: 20% weekly remaining.

Durable source milestone: Brian's new push authorization was used to atomically
push `eae932ad832cbc176adae6ac938cf89f49b214d8` to both
`origin/codex/t55-serial-autoresearch` and the existing PR #630 branch
`origin/codex/t55-cube-pipeline`. Both remote refs were read back at that exact
SHA; PR #630 head and current evidence/acceptance/quota summary were verified.
No local/controller HEAD change, merge, release or cleanup occurred. Essential
run/evidence backup is published on `origin/codex/t55-autoresearch-checkpoint`
at `1ed54a08151db12fdae385fcdc4ee321e4ae5a6e`, under
`tools/perf/imager/evidence/t55-autoresearch-checkpoint/`. Source, archive,
checksums and restart README were independently read back from GitHub. The
20,466,358-byte snapshot preserves controller history, frozen controls, logs,
profiles and the retained/original-reference binaries; it excludes raw MS/image
payloads. Input reconstruction was verified byte-identical using the public
casatestdata MS and preserved owner-bearing table descriptors. PR #630 and
issues #541/#543/#486 link to this durable checkpoint. This is snapshot 14;
later trials require a refreshed snapshot. Latest weekly reading: 18% remaining.

Fresh profile of the retained trial-12 binary completed after trial 14 in 10.96 s,
sampled peak 503,758,848 bytes under the 120 s / 8 GiB guard; artifacts under
`profile-after-trial-14`. GPT-6 Pro (Power 5), signed-in Brian account, accepted
one bounded independent design consultation on the private replay digest:
https://chatgpt.com/c/6aa1e814-97cc-83e8-b963-e8ee5b9c7432
The supplied prompt includes the newly pushed exact revision, current writer /
reader snippets, measured duplicated SHA work, versioned header-only global
commitment proposal and adversarial test questions. The completed review supports
one bounded experiment, subject to unchanged immutable-seal completion and
adversarial testing. See `oracle-spill-v2-review.md` in the experiment root for
scope, caveats and the local verification decisions. It is not final T55 contract review.

The spill inventory is retained as context, not a trial: about 1003 SHA samples
hash row-varying spill payload/header bytes, and 608/642 pread samples read
managed-spill frames. MS I/O is already bulk and only 0.044 s in the latest
unprofiled initial traversal. Spill read work overlaps replay computation, so
removing it is not an automatic whole-job speedup. No checksum or private-file
format change had been made at that profile boundary. Existing retained replay routes were inspected but
not selected as a candidate; single-pass load-before-compute can lose overlap.

Trial 15 in progress: private managed spill v2 header-transcript commitment,
removing the duplicate raw-payload SHA pass while preserving original-seal,
payload, order, count, version, bounds and EOF checks. The narrow terminal-reader
poison fix is included only in the candidate (the controller parent is immutable;
valid paired executions never exercise that error path). Thirty focused spill
tests passed in 45.86 s including build, sampled peak 2,750,857,216 bytes under
600 s / 8 GiB guard. Added five tests cover independently assembled transcripts,
actual SHA call-input bytes, both writer entries, prefetch, rewinds, empty cases,
repaired-checksum/forged-footer attacks, order/metadata attacks, old/mixed versions
and permanent poisoning. Final retained-replay hash assertions and all runtime
tests are running. No timing result is claimed yet.

The existing ignored medium-VLA initial-weighted discriminator stopped before
artifact construction: captured source blocks 7, expected 6. This occurs before
any spill v2 behavior; no scientific/coverage/count goldens were refreshed. Log
`trial-15-v2-digest-golden.log`, 40.70 s including build, peak 2,586,509,312 bytes.
The failure is not a valid performance hypothesis test or full-input acceptance.
Bounded provenance identified the source-layout change at `e896337d663b05191ded55b05dd508ec6fd8af7e`:
adding time-centroid metadata increased selected-row storage from 65 to 73 bytes
after the six-block golden was introduced at `81556dbc55b187da7219155f66bb2cbd3a2f2138`.

One temporary selected-row digest migration probe passed in 70.16 s including
build, peak 2,819,112,960 bytes. It independently streamed the produced artifact
with a 64-KiB buffer, verified header-transcript v2 digest
`babf4d4db5b8ad181543460ba7a74f923a461dd7b38c70b3645c81195b717dd9`,
and also reconstructed v1 raw-prefix digest `c335165779ae9fceca30e20462b329b52e161c81e3e150d63d2993514a4a9952`.
The latter differs from the historical v1 golden, so this is not evidence that
the 2026-08-30 fixture is still byte-identical. Only the format-dependent digest
golden is updated, with an explicit v2 scheme in the diagnostic output. All
source-shape, weighting, coverage, logical artifact and science goldens remain
unchanged; the old ignored diagnostic remains non-green and is not an acceptance
claim. Temporary probe instrumentation was removed from the candidate and
preserved as `trial-15-digest-probe-source.rs` with its log and resource receipt.
The candidate's complete active runtime suite passed 253 tests, eight ignored.

Trial 15 retained at 23:53:03 UTC as `96afe73f9ec2dc37f35a52700e6d60b05b60e311`.
C/P ratio 0.9821519780, paired 95% interval [0.9732152497, 0.9911707695],
a 1.7848% measured parent-relative improvement. Native/CASA ratio 1.2704134824,
medians 8.961744292 / 7.063502875 s. All seven products passed nRMS <=0.001
against both CASA and the preserved native reference, scientific metadata/WCS/
topology/beam checks and focused affected tests. Verify/guard pipelines completed
in 209.85 / 73.58 s with sampled peaks 2,206,908,416 / 2,697,838,592 bytes.
The controller validates active iteration 15, clean and consistent. Source is
pushed to both authorized origin branches, with exact remote readback. A fresh
retained-binary profile completed in 10.38 s, peak 500,645,888 bytes, under
`profile-after-trial-15`. Quota remains 18% weekly remaining. Snapshot 14 remains
the latest remotely archived evidence; refresh the snapshot at the quota pause.

Trial 16 candidate: share the already computed `FrameLedger::emit` payload
SHA through `GriddedNormalOperatorFrame`'s immutable sink-call borrow. The fresh
profile shows 139 SHA samples in the ledger followed by 138 in the spill writer
over those same bytes. Production writer entries now accept only the compiler's
typed frame; raw-parts helpers remain module-private for implementation/tests.
The borrowed checksum cannot outlive the synchronous sink, adds no heap payload
or persistence field, and is the same digest stored in the compiler descriptor.
Reader checks and the v2 transcript/bytes remain unchanged. Writer SHA evidence
now counts only header input and one final hash; compiler work remains measured
at its owner. The compiler's sink test compares supplied checksum to actual
payload, while the spill call spy proves only one producer payload hash and no
additional writer payload pass. Focused compiler/runtime tests are running.
Quota checked before starting this candidate: 17% weekly remaining.

Trial 16 preflight: 50 compiler tests and 253 runtime tests passed (eight runtime
ignored). The first combined 70.34-s command returned tests exit zero but the
guard rejected `pipeline_exited_with_live_descendants`; it is not a clean
pipeline receipt. Direct cached compiler re-execution passed with clean guard
in 0.50 s (140,460,032-byte sampled peak), and the direct runtime rerun follows.
No production or frozen-control change was made for that setup correction.

The direct runtime rerun completed cleanly in 1.70 s, peak 152,223,744 bytes,
with 253 passing tests and eight existing ignores. Trial 16 was discarded at
2026-09-10 00:07:42 UTC: C/P 0.9888520267, paired 95% interval
[0.9664415615, 1.0117821601], native/CASA ratio 1.2451222267. The interval
does not establish a gain, so the scientific guard did not run. Candidate
`acc5c312ff286639c038a057f1b8b1fbe9382307` was controller-reverted by
`da495460176021a9e34e0343303d56970dfb949e`. Retire this payload-hash reuse
candidate; unchanged retry is not selected. Validated status is active at
iteration 16, clean and consistent, retained ratio 1.2704134824.

Trial 17 candidate: release `codegen-units = 1`, keeping ThinLTO, optimization
level, target features, arithmetic and all runtime/science controls unchanged.
The release profile still uses the default partitioning after trial 5's retained
ThinLTO improvement. This isolates whether one LLVM module per crate improves
optimization of the remaining hot call chains; it is not a claim that the
profile proves a partitioning bottleneck. The pre-cutover release configuration
and both archived/current rejection lists were checked; this candidate has not
been attempted. Prebuild under 600 s / 8 GiB, then the unchanged controller
measurement and guard. Disk headroom is 103 GiB; weekly remaining is 17%.

Trial 17 prebuild completed cleanly in 148.15 s with sampled peak
5,986,615,296 bytes under the unchanged 600 s / 8 GiB guard. Only Cargo.toml's
release codegen-unit count differs. Existing dead-code warnings remain; no
scientific source changes. Weekly quota refreshed to 16% remaining before
controller finalization. Proceed to the fixed five-pair timing/guard.

Trial 17 retained at 2026-09-10 00:19:57 UTC as
`df18d670ff50e1e88247af4d25caa92d364d70ad`. C/P 0.9755542689 (2.4446%
improvement), paired 95% interval [0.9636441774, 0.9876115624]. Native/CASA
ratio 1.2364819619, medians 8.551178250 / 6.885626042 s. All seven products
passed both CASA/native-reference comparisons and metadata/WCS/topology/beam
checks; focused release guards passed. Verify/guard completed in 165.25 /
192.13 s, sampled peaks 532,103,168 / 3,116,040,192 bytes. Clean consistent
controller status at iteration 17. Additional release-codegen interop tests
completed in 40.41 s, sampled peak 1,528,233,984 bytes: 15 tiled table tests and
23 C++/Rust image tests passed; the optional CASA-Python case is being rerun
explicitly with the configured CASA interpreter. Weekly allowance is 16%.

The explicit CASA-Python degenerate-axis image test passed in 9.87 s, peak
358,727,680 bytes. The retained-build profile completed in 9.72 s, peak
489,865,216 bytes. Trial-17 source was atomically pushed to both authorized
origin branches and read back at its exact SHA; archive 14 still awaits refresh.

Trial 18 candidate is the **one evidence-producing retry of tile-commit
indexing overhead**, not a reset of trial 13's hypothesis allowance. The fresh
post-codegen profile still attributes 361 exclusive samples to commit_two_domain.
Use contiguous row slices and standard slice zips, rather than the retired
multidimensional ndarray Zip mechanism. Grids/compensations are private standard
arrays constructed by domain_planes; tile arrays are rebound by bind_geometry.
No copies, heap growth, iteration reordering, floating-point reassociation,
format changes or unchecked indexing are introduced. The exact scalar-reference
test from trial 13 is reused, covering overlapping/clipped rectangular tiles,
two planes, signed zero, cancellation and compensations. If the retry misses,
retire tile-commit indexing rewrites as a family, not just this implementation.
The quota reading before editing was 16% weekly remaining.

Trial 18 focused gridded-operator tests passed under a clean process guard in
38.19 s, sampled peak 1,760,182,272 bytes. Formatting and whitespace checks
passed. The pre-cutover paired planned-grid update's direct storage mechanism
was re-inspected; no legacy fallback or alternate path is restored. Proceed
once through controller finalization with unchanged timing/scientific controls.

Quota stop triggered during trial 18: the live 10080-minute weekly window now
reports 85% used / 15% remaining (reset Unix 1789435318). No trial 19 or further
experiment is authorized until explicit resumption. Complete the in-flight
controller action, preserve a clean source/evidence checkpoint remotely, then
pause. This is not a completed performance goal; the controller's active event
status and immutable history must not be forged into scientific completion.

The read-only coverage-reuse inventory found no missing optimization: initial
science already adopts each immutable weighting checkpoint and hashes only its
terminal completion. The later derived-coverage route is already implemented
and cannot pre-authorize an initial stream whose exhaustive proof is not sealed.
Do not retry this as removal of purported duplicate initial science hashing.

The earlier authorized five-trial foreground codex-autoresearch campaign stopped
at its configured cap on 2026-09-09 at 18:40:39 UTC. No trial was retained;
the recorded metric remains 13.756011125 s versus target 7.091937 s.
The serial gap is reduced, not closed. Further worker scaling remains paused;
no full-input run was made under this sequencing change.
The requested matched CASA timing completed at 17:28 UTC on 2026-09-09;
the intermediate worker-scaling measurement completed at 17:17 UTC.
The preceding implementation checkpoint was paused
ahead of its 17:18:25 deadline. Full-input acceptance remains unfinished.
The user approved the
bounded-memory outcome with “Proceed” on 2026-09-09 and approved the dirty-tree
checkpoint. Checkpoint `ed70cd0c3e6329c1f55b9134e80a73979aace813` is local,
not pushed. The user-owned source-study note remains untouched.

Oracle 6 Pro, power 5/5 completed and its review was retrieved after the Mac was
unlocked. It reviewed the pinned pre-refactor source, not the current local
implementation. Its recommendations are incorporated into the accepted boundary:
explicit windows, existing typed tiled storage, global barriers, canonical hashes,
complete native-atom prediction halos, and atomic product publication.

Oracle review: https://chatgpt.com/c/6aa0e7cb-6b38-83e8-b926-f8d45cf9d007

## Latest: normal-state bulk-copy improvement retained

Current local commit: `ec8a292389` on `codex/t55-serial-autoresearch`, replacing
owning-ndarray element traversal in `PagedNormalArray::read` with contiguous
`copy_from_slice`. The temporary slice-result allocation remains unchanged;
this experiment isolates the traversal cost rather than claiming read-into
storage has been implemented. It preserves cache, bounds, telemetry, lifetime,
and storage semantics. The original five-trial controller is not resumed or
rewritten; its baseline, result, and stop remain historical evidence.

Command: `PYTHONDONTWRITEBYTECODE=1 python3 /private/tmp/casa-t55-normal-copy.a0sWOO/run.py`.
The standalone one-candidate runner reuses `build_application`, `image_case`,
the process guard, and product comparator from the existing harness. It records
the exact source diff, parent/candidate binary identities, and unchanged input;
warms both binaries; runs five alternating pairs; then compares all seven
products to the preserved native reference at nRMS <= 0.001.

Result: geometric paired end-to-end improvement 12.7705%, approximate 95%
log-ratio interval 8.9414% to 16.4386%. Parent/candidate medians are 17.629378 /
15.018652 s. All five pairs improved (parent -> candidate seconds: 16.083428 ->
14.497497, 17.516698 -> 15.018652, 17.629378 -> 14.759730, 19.123009 ->
16.452427, 20.015054 -> 18.157891). Host timing drift is substantial; do not
compare the new candidate scalar directly to the old 7.091937 s CASA result or
old 13.756011 s native scalar. This is contemporaneous parent/candidate evidence,
not a refreshed CASA-parity claim. Initial-traversal medians 9.041308 / 9.230834 s
show that this change targets other normal-state handling, not the initial gap.

All seven full product arrays have zero measured differences (stricter than
the allowed 0.001); topology, direction WCS, and metadata match. Five focused
`paged_cube_state::tests::` release tests passed, including exact storage bits,
edge/overflow rejection, cache/ledger bounds, and last-owner cleanup. `cargo fmt
--all -- --check` and `git diff --check` passed. No arithmetic or reconstruction
behavior changed, so unaffected prior reconstruction evidence is reused.
Pipeline completed in 249.901 s under 600 s, sampled process peak 2,053,947,392 B
under 8 GiB, one worker and 4 GiB native authority throughout. Detailed logs,
comparison, source/binary/input identities, and result are in
`/private/tmp/casa-t55-normal-copy.a0sWOO`.

Historical MS evidence: the deleted ledger remains at
`74c991e182^:docs/tutorial-parity/imperformance-wave-2-acceleration-ledger.md`
lines 530-567. Typed DATA/FLAG tile decode plus direct sample-stream replay
removed per-block PlaneInput/VisibilityBatch rebuilding: historical frontend
50.254 -> 35.376 s, MS values 17.938 -> 8.284 s, processing-buffer preparation
10.725 -> 4.382 s, with an admitted 0.85 GiB RSS increase. These are historical,
different-workload results, not current predictions. The retained summary at
`docs/tutorial-parity/imperformance-wave-2-experiment-summary.md:132-166` preserves
row/channel runs, direct tile updates, and shared tap centers, plus rejected broad
MS-read and specialized correlation/channel-packing attempts.

Current `VisibilityBuffer` retains reusable columnar destinations, typed reads,
grouped scalars, and parallel column fills. The active native selected-observation
route uses `SelectedObservationBuffer` instead: reusable typed destinations and
grouped scalars remain, but columns are read sequentially and tile patch planning
is repeated. This structural difference is not proof of the present bottleneck.
Fresh candidate-4 trace shows source reads 60.108 ms, fill 61.183 ms, row
arrangement 52.082 ms, overlapped stream source fill 126.545 ms, versus combined
route/consumer 10.9874 s. Do not add nested/overlapped timings or call all consumer
work buffer assembly. Next prioritization should follow the consumer's repeated
transforms, record construction/serialization/checksums and normal/product passes,
retaining efficient row/run representations rather than assuming raw disk I/O.

Strategy consultation: Oracle 6 Pro / power 5 of 5 received explicit current
excerpts and historical references after user authorization. The page ended at
"Stopped thinking" without returning an assessment; no review acceptance is
claimed. https://chatgpt.com/c/6aa1ab2b-2e7c-83e8-9901-a414e7998eea . Installed macOS
synthesis library has neither an OpenMP dependency nor imported OpenMP symbols;
conditional source and bundled libgomp do not establish OpenMP execution. FFTW
has separate thread support, but actual kernel thread counts were not measured.
No OpenMP explanation for the serial gap is claimed.

## Earlier: bounded serial autoresearch stopped at five trials

User correction after the five-trial run: scientific array agreement uses the
normal 1:1000 normalized-RMS tolerance, not bit-for-bit identity:
`RMS(candidate - reference) / RMS(reference) <= 0.001` (the harness field
`diff_rms_over_right_rms`). This supersedes the zero-difference requirement for
future scientific comparison guards. Preserve the existing zero-reference,
nonfinite, topology, WCS, metadata, and resource checks unless separately changed.
The completed campaign's immutable configuration and actual evidence below are
not rewritten. No candidate was rejected by the product-difference threshold:
trial 2 passed it, and the others failed timing before comparison. Thus this
correction does not change any recorded keep/revert decision. The run remains
stopped at five trials; no new run or expanded iteration limit was requested.

On 2026-09-09 the user approved codex-autoresearch as proposed, including the
necessary branches and bookkeeping. The existing 74-file worktree state,
including the pre-existing source-study document, is preserved in checkpoint
`56d027adde` on `codex/t55-serial-autoresearch`; the prior
`codex/t55-cube-pipeline` branch remains at `ed70cd0c3e`.
This is a local WIP checkpoint, not full-input acceptance or merge approval.

Campaign: one-worker end-to-end serial median seconds, lower is better;
target 7.091937 s (the retained matching CASA tclean median); at most five
foreground experiments. This intermediate 256-square, 16-channel fixture is
unchanged. Reaching its target does not close T55 or establish full-input
bounded-memory acceptance. No full-input, worker-scaling, GPU, push, merge,
cleanup, or release is included.

Validated run `204d1555d0014de29752be0a662efa2b` initialized at baseline
13.756011125 s on preparation commit `b0d8ea8e21`; all seven exact-product
checks and the 110 focused tests passed. Foreground Goal continuation is bound
to the target or five-trial terminal status, without calling a target miss
scientific acceptance. One setup-only failure (string instead of Path passed
to tree_identity, before imaging) was corrected and archived explicitly under
`autoresearch-results/archive/20260909-181415`; no experiment was consumed.

Measurement is `python3 tools/perf/imager/t55_serial_autoresearch.py verify`;
guard is the same command with `guard`. Both use
`CASA_RS_T55_AUTORESEARCH_ROOT=/private/tmp/casa-t55-autoresearch.s4t80L` and
`PYTHONDONTWRITEBYTECODE=1`. The metric is the explicit final JSON key `seconds`.
The immutable metric harness is committed before initialization and excluded
from the experimental edit scope. It builds once, warms both binaries, runs
three alternating parent/candidate pairs, and measures the existing
execute_continuum-through-publication boundary. No build, profile or comparison
overlaps those timed calls. Each command has a 600 s / sampled 8 GiB process-scope
guard; native imaging authority remains 4 GiB. Guarded improvements must exceed
1% against the retained scalar and in all three contemporaneous pairs, preserve
all seven product arrays/topology/WCS/metadata exactly against the frozen native
reference, and pass the affected 110-test reconstruction set plus formatting.
The pre-existing CASA exact-beam-metadata qualifications still apply.

CASA phase diagnostics are now measured, not inferred from log timestamps:
`/private/tmp/casa-t55-autoresearch.s4t80L/casa_phases.py` invoked the existing
PySynthesisImager probe with the matched selection/start/channel count, science
controls, and readonly isolated input. Four runs completed in 32.007 s under
180 s / 8 GiB, peak 554,483,712 B. Discarding the first, diagnostic medians are
PSF 1.138499 s, initial residual 1.061385 s, subsequent major cycles 2.839736 s,
minor cycles 1.452034 s, restore 0.089878 s, total 6.814148 s. The Python helper
envelope is not identical to tclean, whose retained 7.091937 s remains the target.
Cycle summaries confirm two minor cycles / two refreshes after initial and
19 aggregate iterations; input identity is unchanged. The phase log is
`/private/tmp/casa-t55-autoresearch.s4t80L/casa-phases.log`.

A whole-job sample of the current preserved native executable completed under
120 s / 8 GiB (15.083 s outer, peak 505,937,920 B). Among 11,801 sampled stacks
inside execute_continuum, 6,913 are in initial run_phase, 3,228 in subsequent
run_phase calls, and 1,622 in publish_products. These are sampled proportions,
not exclusive elapsed timers. They account for substantial publication and
lifecycle work outside the earlier narrow timers and keep initial traversal as
the primary target. Full profile and logs:
`/private/tmp/casa-t55-autoresearch.s4t80L/whole-profile`.

### Final campaign result

Validated terminal status is `stopped`, reason `configured iteration limit
reached`. Four distinct implementation candidates used five trials, including
one formatting-only retry. All were automatically reverted. Final HEAD is
`3d5655fea8e205045b9474053ba6c4edf69b1f0e`; tracked contents are identical to
baseline/preparation commit `b0d8ea8e21cb45d55febcd9a85e8c8359a10a3f9`, and
`git status --short` is empty. The earlier bounded cube implementation and
matrix-hoisting improvement are preserved in the WIP checkpoint; the campaign
retained no additional optimization. Nothing was pushed or merged.

| Trial | Candidate | Parent median s | Trial median s | Retention result |
| --- | --- | ---: | ---: | --- |
| 1 | Borrow the pending native group | 13.779514 | 13.541678 | Not at least 1% faster in every pair |
| 2 | Reuse identical native prediction rows | 13.473017 | 13.227223 | Formatting-only guard failure |
| 3 | Formatting-corrected retry of trial 2 | 13.473709 | 13.525764 | Not at least 1% faster in every pair |
| 4 | Borrow resampled selected metadata | 13.826986 | 13.283384 | Not at least 1% faster in every pair |
| 5 | Reuse an identical completed resampled atom | 13.433566 | 13.663708 | Less than 1% gain over retained scalar; also slower than paired parent |

Trial 2 passed the three-pair timing guard, the full seven-product exact-array,
topology/WCS/metadata comparison, and all 110 focused tests before failing
formatting. The agent started `finish` before the asynchronous format preflight
had completed; the committed trial was left unchanged and correctly reverted.
The formatting-only repair used trial 3 without resetting the five-trial limit.
Its fresh measurements did not reproduce the required consistent speedup.
Trials 1, 3, 4 and 5 failed the timing guard before full product comparison;
their applicable focused preflights were green. They are rejected performance
candidates, not evidence of scientific regressions or accepted improvements.

The six successful metric pipelines (baseline plus five trials) all completed
inside their 600 s and sampled 8 GiB guards. Maximum outer duration was
145.438021459 s and maximum sampled process-scope RSS was 2,671,591,424 B,
including the application build. Native authority remained 4 GiB; every image
case used one worker, three major cycles, and 19 aggregate minor iterations.
The archived pre-imaging initialization error is excluded from this count.
Since the final source tree is identical to the green baseline, its exact
seven-product and 110-test evidence remains applicable without another run.

The 7.091937 s target was not reached. These trials do not close the serial
CASA gap or provide full-input acceptance. Further experiments require a newly
approved campaign limit; the stopped run must not be silently resumed or
reconfigured. Further worker scaling and the full-input gate remain unrun.

Autoresearch owns the complete trial/revert history and validated state under
`autoresearch-results/`. The generated `autoresearch-results/report.html` is
a read-only report, not a second source of state. Each trial's build, paired
measurement, guard result, and products are preserved under
`/private/tmp/casa-t55-autoresearch.s4t80L/commits/<trial-commit>/`.
This file remains the one current scientific/work-scope summary. The bounded
read-only hot-loop inventory completed on GPT-5.6 Luna Max; implementation and
acceptance decisions remained with the primary agent.

## Earlier: first serial-gap reduction

At 17:30 UTC the user directed serial-gap reduction before further thread
scaling. This pass kept the same intermediate workload, one CPU worker,
4 GiB native authority ceiling, 8 GiB process-scope guard and all product checks.
No public API, persistent format, science formula or concurrency policy changed.

The existing profile selected the initial weighted traversal, not disk reading:
the parent spends about 8.7 s in that region, with approximately 48 ms source
read time. One eight-second sample of the preserved parent executable exposed
repeated `PolarizationOperator::compile` and its small matrix multiplications
inside both science consumption and gridded replay compilation. The pre-cutover
weighting implementation was inspected for its invariant-work treatment.

`SpectralOperatorSpecification` now compiles each distinct selected correlation
layout's direction-independent matrix once. The standard science and replay
record paths borrow it instead of recompiling per correlation group. The
existing matrix compiler still defines every coefficient; arbitrary Mueller
and parallactic-angle operators retain their existing route. The immutable
matrix payload is included in the specification's physical memory projection.
The second touched file is `gridded_normal_operator/spectral_records.rs`.

| One-worker median, three alternating pairs | Parent s | Candidate s |
| --- | ---: | ---: |
| Complete execute_continuum through publication | 14.806300917 | 13.440109083 |
| Initial weighted replay | 8.547032167 | 7.195297917 |

This is 9.227% less whole-job elapsed time (1.102x), saving 1.366 s.
All three pairs favored the candidate. The remaining serial time is 1.895x
CASA's 7.091937 s; the gap is explicitly not closed. The concurrently matched
parent median differs from the earlier 15.091 s workstation measurement, so the
paired 14.806 s value is used for this change's benefit.

A single candidate pilot took 13.473193209 s and completed three major cycles
and 19 aggregate minor iterations. Its comparison request initially omitted
the required empty `products` tolerance map; that harness-only error was repaired
and comparison resumed from retained products without rerunning imaging.
Pilot and final measured candidate products match their parent exactly across
all seven full arrays, masks/topology, coordinates, units and beam metadata.
This preserves the earlier CASA numerical evidence and its separate exact-beam
metadata flags; it does not turn those flags or full-input acceptance green.

All six measured jobs completed with three major cycles and 19 aggregate minor
iterations. The guarded measurement plus comparison took 92.724227 s under
600 s; sampled process-scope peak was 518,144,000 B. Input and both executable
identities were unchanged. No builds, other tests or profiles overlapped the
six timed imaging calls. OS cache was not purged; output/backing paths were fresh.

110 directly affected release unit tests passed: specification metadata (1),
polarization filter (5), spectral operator (54), and gridded normal operator (50).
Two pre-existing ignored spectral tests remained ignored. The metadata test
also proves repeated lookups return the same compiled matrix, coefficients
match the original compiler, unknown layouts fail closed, and matrix bytes are
charged. Formatting and diff whitespace checks pass. The only edits after the
measured executable was built were test assertions, formatting and documentation.

Artifacts: `/private/tmp/casa-t55-serial.d5AeGJ` retains parent source snapshots,
`serial.sample.txt`, `profile.py`, `measure.py`, build/test logs, preserved
candidate executable, guarded pilot and measured logs, exact comparison bundles,
panels and products. [Paired serial results](/private/tmp/casa-t55-serial.d5AeGJ/measured/results.json).
Parent executable SHA256: `25769d94f98aea61b320780a9b00b08e4e5d4f7a28b222cb40ee0b53b34d1f1b`.
Candidate executable SHA256: `acd3f2b76734fe657f67a964317c7b002b6ecd0c7d9406f67a78ac6fc3ff8cd3`.
No commit, push, merge, cleanup or ticket closure was performed. Serial work
remains the priority; the full bounded-memory outcome below is still included.

## Earlier: matched CASA timing for the intermediate cube

The user asked for the corresponding CASA time with the same parameters.
CASA CASALITH 6.7.6.14 was executed through the existing benchmark harness,
using a byte-identical isolated copy of the exact input below and overrides
imsize=256, spw=0:2~17, channel_count=16, start=2. All other scientific settings
remain those of `t55-clark-cube-development.json`. The CASA log confirms LSRK,
linear interpolation, Natural weighting, standard gridder, per-plane restoring
beams, the same cycle controls, three major cycles and 19 aggregate iterations.
CASA used parallel=False; no MPI timing is claimed. Rust is the existing
optimized release build, not a debug build; it was not rebuilt or rerun.

| Complete imaging-call boundary | Median seconds | Time relative to CASA |
| --- | ---: | ---: |
| CASA tclean, serial | 7.091937 | 1.00x |
| casa-rs execute_continuum, one worker | 15.091286959 | 2.128x |
| casa-rs execute_continuum, four workers | 14.546788666 | 2.051x |

CASA warmup was 7.136734 s; the three subsequent measured calls were
7.085927, 7.091937 and 7.139408 s. The harness's four-run median includes the
warmup (7.114335 s); the comparison above deliberately uses only the last three,
as declared before launch. Each call uses a new output path on the internal SSD.
OS cache was not purged. These CASA measurements followed, rather than were
interleaved with, the existing Rust measurements on the same host.
CASA timing covers kwargs construction and the entire tclean call, including
selection and final product writes; imports, startup/measures checks, input
copying and post-run comparison are excluded. Rust's boundary covers
execute_continuum through publication, excluding setup and product assertions.
The complete CASA-plus-comparison pipeline took 69.651451 s under the 600 s cap;
sampled process-scope peak was 645,873,664 B under the 8 GiB guard. Both source
input and isolated copy remained byte-identical excluding volatile lock files.

All seven full-array product comparisons passed the unchanged 0.001 normalized
RMS tolerance; restoring-beam kernel/area checks also passed (nine checks total).
The largest product normalized RMS difference was 1.430315e-6 for PB; image was
1.277668e-7, residual 1.883409e-7, and mask/sumwt were exact. Inventory, WCS and
topology match. Exact restoring-beam metadata equality is flagged for `.image`
and `.psf`; all other metadata fields match. Passing beam kernel/area numerical
tolerances does not erase those exact-metadata flags or establish full acceptance.
Representative shared-scale panels for all
seven products were inspected; this is not an all-channel visual/full-input gate.
The existing four-worker products were already proven exact to the one-worker
products reused in this CASA comparison.

Artifacts: `/private/tmp/casa-t55-intermediate-casa.yLc6R9` contains the bounded
`run.py`, declared `request.json`, `guard.json`, `input-after.json`, full
`casa-task.log`, `pair.log`, the isolated input, final CASA products and panels.
[CASA timing and product-comparison bundle](/private/tmp/casa-t55-intermediate-casa.yLc6R9/evidence/20260909T172619Z-t55-clark-cube-development-2437754b.json).
Outcome: CASA takes roughly half as long on this matched workload, even against
four-worker Rust. No production change, optimization, commit, merge or full-input
run was made for this request. The implementation remains paused as below.

## Earlier: intermediate worker-scaling measurement

The user requested a practical intermediate workload after noting the lack of
realistic-dataset scaling evidence. Only the existing real-data application test
harness was parameterized; no production algorithm or implementation changed.
The original 128-square/four-channel Natural/Briggs gate is retained unchanged,
and a new ignored test reuses its complete product/scientific comparisons:
`t55_real_cube::t55_intermediate_clark_cube_worker_scaling`.

Input is the existing isolated local `refim_point_withline.ms`: 83,434,343 bytes
excluding volatile lock files, 168,480 rows, two correlations and 20 native
channels. The test selects SPW 0 channels 2–17, yielding 5,391,360 stored complex
samples, and produces a 256×256×1×16 LSRK/linear/Natural Clark cube at 8 arcsec
per pixel. Parameters retain niter=9, cycleniter=1, nmajor=3, gain=0.1,
threshold=0, pblimit=-0.2, all seven products and no model-column write.
Every run completed three major cycles with 19 reported/actual aggregate minor
iterations. Source inspection and executed counters agree on the row/sample
counts; each final replay processes 12,071,756 records from a 482,912,816-byte
retained artifact. This is a nontrivial real-data development case, not the
32-GB full-input acceptance workload.

Hardware: Apple M4, 10 physical/logical cores, 32 GiB RAM, internal SSD.
Resource settings: 4 GiB native authority ceiling and sampled 8 GiB process-scope
RSS guard, below the previously approved ceilings. Input, scratch and outputs
are local. Source and measured executable identities remained unchanged.

One warmup/pilot pair took 30.473931 s under a 300 s cap. Three subsequent measured
pairs took 90.949734 s under a 600 s cap. Orders were 1→4, 4→1, 1→4; neither
timed invocation included a build. OS cache was not purged; the pilot warmed the
input and each run had fresh output/backing paths. The first measured case
overlapped one brief read-only formatting check; no compilation or other imaging
process was found. Treat these as bounded workstation measurements, not a
precision scaling benchmark or an extrapolation to larger data.

| Measured boundary | One worker median s | Four workers median s |
| --- | ---: | ---: |
| Complete execute_continuum through publication | 15.091286959 | 14.546788666 |
| Initial weighted replay (one actual worker in both cases) | 8.737082667 | 8.727860959 |
| Two final gridded replay regions, summed per job | 2.390843042 | 1.904303499 |
| Two complete minor-cycle regions, summed per job | 0.662903000 | 0.648936000 |
| Three major reconciliations, summed per job | 0.404074458 | 0.405654291 |

Whole-job samples were W1: 15.091286959, 15.073675834, 15.140282792 s;
W4: 14.750866459, 14.546788666, 14.416878875 s. Ratio of medians is 1.037431×,
or 3.608% less elapsed time. All three pairs favored four workers, but this is
only a modest whole-run improvement. Final replay shows a clearer local gain;
the initial pass still consumes about 58% of serial wall time on one worker.
Named region timers are not an exhaustive exclusive decomposition of task wall.

All seven product arrays, masks, WCS, units, beam/image metadata, model samples,
normal-state arrays, weights and scientific cycle evidence match exactly within
every worker pair. Run-local affine generation IDs are normalized as in the
pre-existing test. Receipts were reopened and real four-worker participation was
verified in both final replay and minor cycles. CASA comparison was subsequently
completed for this shape as recorded in the latest section above.

Measured process maximum RSS was 527,630,336 B (503.19 MiB), with zero reported
swaps; sampled process-scope peak was 526,942,208 B. The difference reflects
sampling and scope, not an allocation discrepancy. These are actual process
measurements, not the 4 GiB authority reservation or a full-lifecycle heap proof.
Source and replay payload counters are in the logs; they are not device-I/O
measurements.

Artifacts: `/private/tmp/casa-t55-intermediate.RWmlND` contains `input-probe.log`,
`build.log`, preserved `continuum-application`, `pilot.log`, `measured.log`, both
guard/request JSON files, all eight retained product sets and reopened receipts,
`run.py`, `summarize.py`, and [machine-readable results](/private/tmp/casa-t55-intermediate.RWmlND/results.json).
Executable SHA256: `25769d94f98aea61b320780a9b00b08e4e5d4f7a28b222cb40ee0b53b34d1f1b`.
Input tree SHA256: `d62a5398f825f6a96510bd64516ab0ad731ce73a75201230d995b4df965be8f0`.
For a new run, use a fresh artifact root with the checked-in ignored test,
`CASA_RS_T55_REAL_MS`, `CASA_RS_T55_ARTIFACT_ROOT`,
`CASA_RS_T55_NATIVE_MEMORY_BYTES=4294967296`,
`CASA_RS_T55_TIMING_WORKERS=1,4`, `CASA_RS_T55_TIMING_REPETITIONS=3`, the recorded
spill-rate environment, and the existing external guard. Do not overwrite these
accepted artifacts. Post-run formatting and diff whitespace checks pass.

Outcome: the feedback loop is now approximately 15 seconds per intermediate
job. The useful next performance target is the executing initial-pass path,
not another increase to dataset size. No optimization was started after these
measurements; all unfinished full-scope work below remains included.

## Earlier measurement-first checkpoint

The 16:18:25 UTC instruction changes sequencing, not scope: obtain a bounded
parent/current measurement, then only the integration needed for a small complete
canonical CLEAN with matching products. Pause by 17:18:25 UTC (11:18:25 Denver);
no full-input run. The complete accepted outcome below remains unchanged.

### Measured parent/current paging result

All four warmups and all 12 measured invocations passed exact element checks.
Release builds run the same harness: 128 MiB logical f64 data (16,777,216 values)
or 128 MiB logical Boolean data (134,217,728 values, packed on disk), a
4096-scalar tile, one-tile cache, 65,536-scalar access windows, and three complete
write/flush/read/verify sweeps plus close/reopen/tail checks per invocation.
One warmup precedes three paired runs, with the second pair reversed.

| Median process measurement | Parent ed70cd0 | Current typed storage |
| --- | ---: | ---: |
| f64 wall | 0.17 s | 0.17 s |
| Boolean wall | 1.55 s | 1.67 s |
| f64 peak RSS | 3,981,312 B | 3,489,792 B |
| Boolean peak RSS | 3,538,944 B | 3,440,640 B |

No throughput improvement is demonstrated; Boolean paging is 7.7% slower.
Reads immediately follow writes and are OS-cache-warm. Configured cache limits
are not measured heap. Baseline physical-I/O counters are unavailable; macOS
zero block-operation counters do not mean no file I/O. Exact source/binary
hashes, paired run order, commands, phase medians/ranges, and all raw logs:
[paging results](/private/tmp/casa-t55-paging-compare.uoYaiP/RESULTS.md).
This is a component comparison, not an end-to-end CLEAN speedup.

### Small canonical production result: green

Two application tests execute 14 complete 64×64×4-channel Clark CLEAN jobs:
eight compare window depths 1/2/3/4 on one worker, and six separately compare
1/2/3 workers at full depth, both for Natural and Briggs(0.5). Input is the
existing one-row, four-channel, four-correlation synthetic MS (16 stored
complex samples), with nonuniform amplitudes and a blank output channel.
The output axis is descending TOPO, common restoring beam, gain 0.37,
three requested iterations, cycle iteration setting 1, and at most three
major cycles. Every job completed three major cycles and three actual minor
iterations.

For each weighting, all six products (.psf, .residual, .model, .image, .sumwt,
.mask) match bit-for-bit across partitions, including dimensions, validity
masks, units and endpoint WCS. Model samples, normal residuals, sum weights,
actual iteration count and major-cycle count also match. Blank-channel and
no-PB stored-mask semantics are asserted. This fixture uses aligned native
channel centers; it does not establish the full cross-interpolation CLEAN
falsifier or CASA numerical/visual acceptance.

The normal planner, not a forced window switch, selects initial and both
final-major core depths 1/2/3 from 9/10/11 MiB authority ceilings respectively.
Unconstrained runs select depth 4. Those ceilings are not whole-process RSS
limits.

| One-worker case | Natural execute_continuum s | Briggs execute_continuum s |
| --- | ---: | ---: |
| Full window | 0.333102667 | 0.265790125 |
| Depth 1 / 9 MiB | 0.268152333 | 0.282638750 |
| Depth 2 / 10 MiB | 0.276784584 | 0.292914375 |
| Depth 3 / 11 MiB | 0.282975209 | 0.280743292 |

Separate full-window worker-count cases took 0.245488042/0.245107208/0.251044708 s
for Natural workers 1/2/3, and 0.257227583/0.257154250/0.263191959 s for Briggs.
These are single traced invocations, not a scaling benchmark. The boundary
includes selection through publication, excluding fixture creation and
post-execution assertions. The shared test process took 4.44 s wall, 1.53 s
user, 0.94 s system, peak RSS 52,609,024 B (50.17 MiB), zero reported swaps.
A runtime test build began alongside this invocation, so timings are diagnostic
and not controlled throughput evidence.

Within the eight one-worker window cases, summed instrumented initial FFT
time ranged 0.358–0.405 ms, initial primitive formation 0.075–0.092 ms,
three major reconciliations 5.993–6.521 ms, and two minor-cycle calls
12.808–14.405 ms. These cover named regions, not an exhaustive/exclusive
partition of end-to-end time. Raw per-stage and replay timings remain in the log.

Command (release build, CARGO_INCREMENTAL=0, CARGO_BUILD_JOBS=2):

```sh
/usr/bin/time -l env RUST_TEST_THREADS=1 CASA_RS_TRACE_IMAGING_STAGE_TIMING=1 /private/tmp/casa-t55-checkpoint.kgOTpC/canonical-cube-windows t55_cube_pipeline::t55_clark_cube_products_and_repeated_cycles_are_exact_across_ --nocapture
```

Measured executable SHA256:
`c8c2e9892ab82656511015cb2764139f722b55a27e44ddf8613f72a8298ef497`.
Preserved executable: `/private/tmp/casa-t55-checkpoint.kgOTpC/canonical-cube-windows`.
Build log: `canonical-windows-build-fold-current.log`; successful raw log:
`canonical-windows-fold.log` in the same directory. Later edits were formatting
and runtime-test fixture changes, not changes to this measured implementation.

### Measured cube backing versus projections

For each new model-plus-normal generation in the small job, the observer reports
110,395 B owned backing heap, of which 102,400 B is cache and 181 B is cache
index; two backings, three open files, and 1,314,937 B logical file length.
These values stay constant across core depths 1/2/3/4. They are backing-owner
measurements, not all simultaneously live generations or whole application heap.
The planner reserves 115,373 B initially / 115,365 B on later generations for
retained backing and related metadata.

| Core depth | Maximum observed scalar access | Projected access scratch B | Initial-generation observed read B at first minor boundary | Observed write B at that boundary |
| --- | ---: | ---: | ---: | ---: |
| 1 | 8,192 | 131,080 | 4,214,784 | 1,181,696 |
| 2 | 16,384 | 262,152 | 4,083,712 | 1,050,624 |
| 3 | 24,576 | 393,224 | 4,149,248 | 1,116,160 |
| 4 | 32,768 | 524,296 | 4,083,712 | 1,050,624 |

Read/write values are measured typed-storage payload transfers through that
snapshot, not physical-device bytes. They exclude metadata I/O, set_len, and
flushes after the last printed snapshot; old-generation reads can continue after
its last snapshot. The figures are not whole-job totals. Gridded replay has
separate per-window observations (288-byte artifact, three encoded records);
complete multi-window replay and product-I/O aggregation is still unaccepted.

### What is now connected

- Runtime binds the explicit paged model-value/support and normal-state factories
  before allocation; private directories own deletion and retained resource leases
  outlive files and arrays. Temporary-storage and FD claims export at preparation,
  and backing heap exports at the terminal science boundary.
- Initial ChannelLocal empty-seed CLEAN and final-major replay choose the deepest
  window whose whole composed phase quote fits. Final windows also respect the
  previous backing's read capability and complete native-atom prediction envelope.
- ChannelLocal folds write directly into paged fields with ordered coverage and
  canonical field-major hashes. The obsolete resident full-cube fold reservation
  was removed after direct ownership inspection. Taylor/coupled fold reservations
  remain.
- Global CLEAN thresholds/barriers and ordered deltas are retained; model/normal
  consumers use explicit reads. Coupled Constant/Taylor/Joint representations are
  preserved, not silently redirected through a fallback.
- Product generation, hashing, sealing and CASA image/mask staging use windows.
  Publication remains at the complete-generation barrier.

### Focused gates and limits

- Small canonical application tests above: 2/2, covering 14 complete jobs.
- PagedArray 15/15; typed Boolean cache budget 1/1; runtime physical pager 5/5;
  artifact retention 13/13; product window/hash/coverage/failure tests 3/3.
- Earlier affected normal-storage and T41 checks passed. Eight T55 native-atom
  replay tests matched full and 1/2/3/5 windows on a 17-channel coarse-native/
  fine-output fixture, including full normal-state identity. That lower-layer
  check is not the missing canonical interpolation-boundary CLEAN comparison.
- Updated bounded CLEAN admission and slab execution: 3/3 green. The migrated
  28-channel/8-square CLEAN fixture uses the existing 1 MiB test authority with
  Exclusive policy; its old Balanced reserve left only 786,432 B below the
  measured 808,024 B one-channel requirement. It asserts bounded success and
  exact one-byte-below-minimum rejection. Both older dirty fixtures now supply
  the required storage binding and assert the paged fold rather than a resident
  full-cube accumulator. Command:
  `CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test --release -p casa-imaging-runtime --test compile_plan_run t607_ -- --nocapture`.
  Log: `/private/tmp/casa-t55-checkpoint.kgOTpC/runtime-t607-fixture-retry.log`.
- Serial publication success/failure/foreign-generation tests: 4/4 green;
  production storage-profile admission: 1/1 green. Commands used
  `RUST_TEST_THREADS=1 target/release/deps/compile_plan_run-46c509babb29518e`
  with filters `serial_product_publication_` and
  `--exact production_storage_profile_admits_serial_scientific_and_publication_plans`.
  Logs: `runtime-publication.log` and `runtime-storage-profile.log` in the same
  checkpoint directory. Later fixture-only changes do not affect this evidence.
- Formatting and diff whitespace checks are green. Six runtime warnings identify
  test/diagnostic-only pager accessors and deletion-owning directory fields.
- Two model-lifecycle identity goldens and one product golden were reproduced
  unchanged in the checkpoint archive; expected values were not edited. Parent
  archive: `/private/tmp/casa-t55-model-parent.12lHAX`.

Full accepted work remains unfinished: solver-contract sparse delta bounds,
initial nonempty-seed prediction windows, exact complete lifecycle and CASA
writer metadata accounting, actual aggregate I/O evidence, the complete
canonical interpolation/coverage/failure falsifier, remaining directly affected
regressions, anti-slop/API/docs closeout, and full 32-GB / 512-channel CASA
numerical/visual/timing acceptance. These are still included work, not approved
deferrals. No full-input execution, new commit, push, merge, or cleanup occurred
during the measurement checkpoint.

All bounded agents and build/test processes are finished. The current diff has
not received independent final contract review. Next continuation, if requested,
starts from these results and the remaining accepted work above; it does not
repeat the measured pager comparison or start a full-input run without its
required readiness evidence and an agreed execution checkpoint.

## Outcome and boundary

Execute the complete 32-GB MeasurementSet and all 512 output channels at the
current 512-square Natural/linear/Clark request under the effective resource
capacity of approximately 12 GiB. This capacity is not a whole-process RSS
promise. Preserve the existing full-input comparison and timing obligation.

The coherent scope is active-window ownership throughout initial major cycle,
CLEAN/model continuation, final-major replay, and product publication. The
narrow alternative—only enable existing slab planning—is rejected: its normal
fold and downstream consumers still retain full-cube arrays. No new frontend,
external format, science approximation, runtime fallback, or full-MS route.
Coupled Taylor/Joint science is retained and regression-tested where shared
interfaces change; it is not independently redesigned.

## Evidence and reuse

- `spectral_cycle_plan.rs:905`: CLEAN excludes ChannelLocal from slab planning.
- `complete_data_operator.rs:2131`: existing ordered slab planning includes a
  full result/fold allocation; reducing worker count leaves the same floor.
- `spectral_operator.rs:2741`: primitive payloads are full Box slices;
  `CompleteDataOwnerSlabFold` expands/retains the full result.
- `major_cycle.rs:67`: `FinalNormalState` combines lineage with owned full
  payloads and borrowing domain/plane accessors.
- reconstruction `lib.rs:486`: `ModelGeneration` owns full model samples;
  delta validation and application index that complete backing.
- `reconstruction_cycle.rs:486,745`: a global threshold, independent plane
  work, ordered commit, and exact completion evidence already exist.
- runtime `managed_spill.rs:55,598,950`: authority-bound temporary storage,
  bounded framed writes/read windows, retention ownership, integrity checks,
  I/O measurements, and deletion-owning artifacts are available. Its current
  immutable sequential replay interface is not already a mutable cube store.
- products `authority.rs:1390` has per-plane algorithms; runtime
  `serial_product_publication.rs:742` retains complete produced payloads.

The selected ten source entry files total 35,312 lines. This is an inspection
envelope, not a proposed rewrite. The application-facing execution interface
does not need expansion. Internal whole-payload accessors will be replaced at
the affected seams; exact deleted/exported symbol counts follow the reviewed
implementation, not speculative counts of every `pub` in these crates.

## Proposed ownership and migration

1. Keep science payload layout, content/coverage validation, and global
   reductions with reconstruction/products. Keep filesystem, descriptor,
   buffer, storage-capacity, and lease ownership in runtime. Do not introduce
   a reverse reconstruction-to-runtime dependency.
2. Define bounded normal/model window access with explicit lifetime and failure
   handling. Keep full scientific completion identity separate from resident
   payload size. A window can cover the full axis when it fits; that is the
   same route, not a separate in-memory implementation.
3. Replace ChannelLocal concatenating folds with ordered backing writes and
   terminal coverage/lineage sealing. Retain only admitted active windows and
   bounded metadata. Preserve interpolation/prediction halo coverage.
4. Stream the cube-wide CLEAN statistics first. Freeze the existing shared
   threshold/mask semantics, then reuse the independent plane executor and
   canonical ordered delta/evidence commit. Ensure model update, validation,
   and continuation do not require a full resident generation or duplicate
   dense delta. Bound sparse terms using the real solver contract.
5. Reuse the same backing/window lifecycle for final-major replay. Make stale
   state, partial coverage, cancellation, and I/O errors terminal; no partial
   generation becomes authoritative.
6. Produce and stage one admitted product window at a time. Keep all-product
   validation, required beam/global reductions, generation sealing, and the
   single atomic publication barrier. Do not publish planes independently.
7. Remove the old whole-cube CLEAN dispatch/fold assumptions, migrate all
   affected callers/tests/rustdoc, and update the canonical PR work record at a
   meaningful verified milestone. Leave unrelated source-study notes alone.

## Planning rule

For worker count w and core depth d, enumerate the actual execution phases p:

    peak(w,d) = shared_retained + max_p(
        active_arrays_p(d, required_halo)
        + w * worker_scratch_p
        + stack_p(w) + io_buffers_p + transition_overlap_p)

Choose feasible (w,d) using existing resource-selection policy, with checked
byte arithmetic and actual dimensions, dtype sizes, worker/queue bounds, and
phase lifetimes. Count metadata, serialization, descriptors, scratch storage,
and model/delta overlap explicitly. Temporary storage gets a separate capacity
bound. No hand-selected 32/64/128-channel constant or accounting discount.
The final formula must be derived from the implemented allocation ledger.

## Verification and stop points

First falsifying check: execute the same small multichannel CLEAN problem
through the canonical path with one full window and constrained 1/2/3-channel
windows. Include signal spanning an interpolation boundary, blank/unmapped
channels, more than one major cycle, and nonuniform peaks to expose accidental
per-window thresholds. Compare model/delta/evidence and every product; count
live payload bytes and backing I/O, not only planner estimates.

Extend existing `t55_prepared_cube_planes_preserve_results_and_require_exact_ordered_coverage`
and application cube fixtures. Replace the old
`t607_clean_cycle_rejects_a_plan_that_cannot_retain_every_cube_plane` invariant
with bounded success plus genuine minimum-window rejection, preserving failure
coverage. Retain T41 slab/Taylor and directly affected model/product/publication
contract tests, including out-of-order/missing windows and cancellation/failure
before the publication barrier.

Only after local execution is correct, use the full 32-GB dataset for actual
timing and complete CASA numerical/visual acceptance. No reduced-input timing
claim. Confirm disk/storage and an agreed execution checkpoint before a long
or unattended run. No new overnight checkpoint has been agreed yet.

## Revert point

Checkpoint HEAD: ed70cd0c3e6329c1f55b9134e80a73979aace813, parent
b7c482f72b7d8375dc86c97f96bc12248c734f15. It contains exactly the 16 preceding
T55 science/timing-harness files. The unrelated untracked source-study document
was excluded. Nothing was pushed.

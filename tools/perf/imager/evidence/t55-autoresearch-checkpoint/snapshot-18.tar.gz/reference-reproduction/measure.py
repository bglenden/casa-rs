"""Guarded prebuilt serial parent/candidate measurements and exact products."""
import json
import os
from pathlib import Path
import re
import statistics
import subprocess
import sys

REPO = Path('/Users/brianglendenning/.codex/worktrees/5d43/casa-rs')
ROOT = Path(__file__).resolve().parent
MS = Path('/private/tmp/casa-t55-real-density-accounted.p5Medq/input/refim_point_withline.ms')
PARENT = Path('/private/tmp/casa-t55-intermediate.RWmlND/continuum-application')
CANDIDATE = ROOT / 'candidate-application'
CASA = '/Applications/CASA.app/Contents/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
sys.path.insert(0, str(REPO / 'tools/perf/imager'))
from perf_harness import t51_pair_guard
from perf_harness.image_compare import compare_products
from perf_harness.tree_identity import sha256_file, tree_identity


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def identity():
    result = tree_identity(MS, excluded_names={'table.lock'})
    result.pop('excluded_count')
    return result


def pipeline(label, compare_only=False):
    group = ROOT / label
    if not compare_only:
        group.mkdir()
    before = identity()
    binaries = {'parent': sha256_file(PARENT), 'candidate': sha256_file(CANDIDATE)}
    schedule = [('candidate', 0)] if label == 'pilot' else [
        ('parent', 0), ('candidate', 0), ('candidate', 1),
        ('parent', 1), ('parent', 2), ('candidate', 2)]
    request = {'schedule': schedule, 'input_identity': before,
                                 'binary_sha256': binaries, 'workers': 1,
                                 'native_memory_bytes': 4 << 30,
                                 'sampled_rss_cap_bytes': 8 << 30,
                                 'wall_cap_seconds': 600,
                                 'cache_policy': 'OS cache not purged; pilot warms candidate; fresh output and backing per invocation',
                                 'timing': 'execute_continuum through publication; builds, product checks and fixture staging excluded'}
    if compare_only:
        original = json.loads((group / 'request.json').read_text())
        assert original['input_identity'] == before and original['binary_sha256'] == binaries
    else:
        save(group / 'request.json', request)
    results = []
    for role, repetition in schedule:
        destination = group / f'{role}-{repetition}'
        environment = os.environ.copy()
        environment.update(RUST_TEST_THREADS='1', RUST_MIN_STACK='16777216',
                           CASA_RS_T55_REAL_MS=str(MS), CASA_RS_T55_ARTIFACT_ROOT=str(destination),
                           CASA_RS_T55_NATIVE_MEMORY_BYTES=str(4 << 30),
                           CASA_RS_T55_TIMING_WORKERS='1', CASA_RS_T55_TIMING_REPETITIONS='1',
                           CASA_RS_TRACE_IMAGING_STAGE_TIMING='1')
        binary = PARENT if role == 'parent' else CANDIDATE
        argv = [str(binary), '--ignored', '--exact',
                't55_real_cube::t55_intermediate_clark_cube_worker_scaling', '--nocapture']
        log_path = group / f'{role}-{repetition}.log'
        print(json.dumps({'role': role, 'repetition': repetition, 'argv': argv}), flush=True)
        if not compare_only:
            with log_path.open('x') as log:
                subprocess.run(argv, cwd=REPO, env=environment,
                               stdout=log, stderr=subprocess.STDOUT, check=True)
        directory = destination / 'natural-w1'
        assert (directory / 'accepted.txt').is_file()
        summary = json.loads((directory / 'summary.json').read_text())
        assert summary['major_cycles'] == 3 and summary['actual_minor_iterations'] == 19
        assert summary['requested_workers'] == 1 and summary['actual_minor_workers'] == 1
        initial = [line for line in log_path.read_text().splitlines()
                   if line.startswith('imaging_source_read_ahead_summary ')]
        assert len(initial) == 1
        initial_nanos = int(re.search(r'\bwall_nanos=(\d+)', initial[0]).group(1))
        results.append({'role': role, 'repetition': repetition,
                        'task_wall_seconds': summary['task_wall_seconds'],
                        'initial_weighted_replay_seconds': initial_nanos / 1e9,
                        'products': str(directory / 'image')})
        print(json.dumps(results[-1]), flush=True)
    baseline = ('/private/tmp/casa-t55-intermediate.RWmlND/measured/round-1/natural-w1/image'
                if label == 'pilot' else next(row['products'] for row in reversed(results) if row['role'] == 'parent'))
    candidate = next(row['products'] for row in reversed(results) if row['role'] == 'candidate')
    comparison = compare_products(casa_python=CASA, cwd=ROOT,
        artifact_prefix=group / 'exact-products', request={
            'left_prefix': candidate, 'left_label': 'candidate one worker',
            'right_prefix': baseline, 'right_label': 'parent one worker',
            'mode': 'full', 'products': ['.image', '.residual', '.psf', '.sumwt', '.model', '.pb', '.mask'],
            'max_elements_per_product': 1000000, 'full_chunk_elements': 1000000,
            'require_exact_product_inventory': True, 'require_direction_wcs_parity': True,
            'require_metadata_parity': True, 'panel_dir': str(group / 'panels'),
            'structure_workspace_dir': str(group / 'structure-workspace'),
            'tolerances': {'contract_version': 2, 'require_full_array': True, 'products': {},
                           'default': {'diff_rms_over_right_rms': 0.0}}})
    save(group / 'comparison-result.json', comparison)
    assert comparison['status'] == 'completed', comparison.get('reason')
    assert comparison['tolerance_evaluation']['status'] == 'passed'
    assert all(value['full_array']['diff_abs_max'] == 0.0
               and value['metadata']['status'] == 'matched'
               and value['direction_wcs']['status'] == 'matched'
               and value['topology_parity'] for value in comparison['products'].values())
    assert before == identity()
    assert binaries == {'parent': sha256_file(PARENT), 'candidate': sha256_file(CANDIDATE)}
    medians = {role: {metric: statistics.median(row[metric] for row in results if row['role'] == role)
                      for metric in ('task_wall_seconds', 'initial_weighted_replay_seconds')}
               for role in {row['role'] for row in results}}
    outcome = {'runs': results, 'medians': medians, 'exact_products': True,
               'input_unchanged': True, 'binaries_unchanged': True}
    save(group / 'results.json', outcome)
    print(json.dumps(outcome, indent=2), flush=True)


label = sys.argv[1]
assert label in ('pilot', 'measured')
compare_only = '--compare-only' in sys.argv[2:]
if '--inside' in sys.argv[2:]:
    pipeline(label, compare_only)
else:
    t51_pair_guard.RSS_BYTES = 8 << 30
    record_label = f'{label}-comparison-recovery' if compare_only else label
    argv = [sys.executable, __file__, label, '--inside']
    if compare_only:
        argv.append('--compare-only')
    with (ROOT / f'{record_label}-pipeline.log').open('x') as log:
        receipt = t51_pair_guard.run_pair_pipeline(
            argv, cwd=REPO, environment=os.environ.copy(), log=log,
            wall_seconds=120 if compare_only else 600)
    save(ROOT / f'{record_label}-guard.json', receipt)
    print(json.dumps(receipt, indent=2), flush=True)
    raise SystemExit(0 if receipt['complete'] else 1)

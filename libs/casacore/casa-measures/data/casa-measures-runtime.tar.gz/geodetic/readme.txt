# measures data populated by casaconfig
version : WSRT_Measures_20260408-160001.ztar
date : 2026-04-08
site : https://www.astron.nl/iers/
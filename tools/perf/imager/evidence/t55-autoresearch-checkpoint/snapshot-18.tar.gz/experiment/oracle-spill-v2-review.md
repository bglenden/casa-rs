# T55 spill v2 integrity review

Completed 2026-09-09, GPT-6 Pro / Power 5 in Brian's signed-in Pro session.
Conversation: https://chatgpt.com/c/6aa1e814-97cc-83e8-b963-e8ee5b9c7432
Source reviewed: eae932ad832cbc176adae6ac938cf89f49b214d8.

Recommendation: one bounded paired experiment. V2 hashes the versioned file
header followed by fixed-width frame headers; each frame header includes the
payload SHA-256, order, record count and payload length. Assuming correct,
collision-resistant SHA-256, this preserves binding to the original immutable
in-memory seal. It is deliberately not a conventional raw-file-prefix digest.
The second raw-payload hashing context in v1 is redundant under those assumptions.
Per-frame verification must precede transcript update, and successful replay
still requires footer, counts, bounds, exact EOF and the original seal.

Independently inspected managed_spill writer/reader/seal, retention, prefetch,
encoding and tests; complete_data_operator descriptor/preparation/completion;
spectral_cycle selection/measurements; serial_compute_probe digest contracts;
bounded_records frame flush; and lib exports. This is a private TempPath-owned
artifact, not CASA-interoperable persistent data. Public replay identity comes
from the program, not the spill digest. No dataset or local profile was read,
and the reviewer did not run tests or a benchmark.

Required implementation/tests: version 2 at all framing levels; outer SHA only
over file and frame headers; unchanged payload validation; adjust four SHA-byte
measurements to payload+16+72*frames (completed artifact bytes minus 80), with
F+1 completed hashes; preserve zero-hash retained replay. Independently verify
the transcript and actual input bytes, both writer entries, prefetch, rewinds,
zero frames and zero-payload frames. Reject repaired-checksum/forged-footer
payload mutations, reordered frames with repaired sequences, redistributed
record counts, v1/mixed versions, and corrupt retained loads under the original
seal. A pre-existing exhausted-schedule footer error failed to poison its reader;
fix it narrowly and test that restoring the footer does not revive the reader.

Local decision: the controller parent must remain immutable. The candidate
includes that terminal error-path fix; the paired parent does not. Successful
benchmark executions do not exercise that error branch. This differs from the
reviewer's suggestion to apply the fix to both builds, without changing timing
controls or resetting the campaign. All other scientific identity goldens and
the separate raw ReplayArtifactSink digest remain untouched.

Keep the existing five-pair wall-time decision, seven products at nRMS <=0.001
against CASA and preserved native reference, metadata/WCS/topology/beam checks,
4-GiB native/8-GiB sampled-process/600-second pipeline bounds. This review and
small fixture do not establish full-input acceptance.

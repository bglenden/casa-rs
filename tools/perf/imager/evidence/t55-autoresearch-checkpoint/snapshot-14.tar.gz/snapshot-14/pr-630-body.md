Work issue: #541

## Current WIP checkpoint — serial autoresearch active, 2026-09-09

The controller-validated source checkpoint is [`eae932ad832cbc176adae6ac938cf89f49b214d8`](https://github.com/bglenden/casa-rs/commit/eae932ad832cbc176adae6ac938cf89f49b214d8), verified on both this draft PR branch `codex/t55-cube-pipeline` and the active branch `codex/t55-serial-autoresearch`. All earlier weighting and bounded cube-lifecycle changes are now committed in this lineage. This is a WIP backup, not ticket acceptance or merge approval.

Brian approved repository-wide serial performance experiments preserving CASA-interoperable MS/image formats and scientific behavior. Foreground autoresearch run: `5643a1a0493c4c7d8f1cd2f3ae30c28d`. Fixed metric: geometric native/CASA task-time ratio across five fresh, paired one-worker measurements, with a fresh retained-parent control. Target 0.90, automatic 20-trial tranches and further significant opportunities beyond parity. The fixture remains 256×256, 16 channels, 168,480 rows, Natural/Clark, three major cycles and 19 actual minor iterations. Limits remain 4 GiB native, 8 GiB sampled process group and 600 s per experimental pipeline.

- Initial ratio: 1.7628787405; retained ratio: **1.2782518014**. This is a 27.49% reduction in the measured ratio, not a full-input or absolute historical speedup claim. The latest retained native/CASA medians were 8.837087083 / 6.921269333 s.
- Retained mechanisms: borrowed model/product ndarray reads (`20487d6367`), exact spectral-axis vector reservation (`f4e0947484`), release ThinLTO (`e38e84e418`), shape-aware backing reads (trial 7), shared resampler current borrowing/stable previous slot (`68d0d16bba`), and the bounded problem-bound source-channel spectral cache (`3bd0f90c69`). Earlier normal-read improvement `ec8a292389` is also preserved.
- The most recent keep, trial 12, improved its fresh parent by 4.8518%: C/P 0.9514819838, paired 95% log-ratio interval [0.9400615186, 0.9630411920]. All seven products passed nRMS ≤0.001 against CASA and the preserved native reference; metadata/WCS/topology/beam checks and affected focused guards passed. Guard: 72.85 s, sampled peak 2,864,463,872 bytes, clean completion.
- Trials 13 and 14 are completed, discarded and visibly reverted: shaped-Zip tile commit and flat-row standard degridding. Neither established a parent-relative improvement; their scientific comparison guard therefore did not run. Trial 13 C/P 0.9815123329 [0.9447233138, 1.0197339745]; trial 14 C/P 0.9977983954 [0.9731135009, 1.0231094698]. Their bitwise arithmetic preflights passed. These candidates are retired.
- Trial-12 focused library preflight: 220 reconstruction and 248 runtime tests passed (17 and 8 existing ignored). The broader `compile_plan_run` suite has 88 failures / 91 passes, reproduced as exactly the same failing test-name set on the isolated parent. Most fail at pre-existing `MissingPointingQueryDomain`; legacy workspace assertions also remain. No tests were weakened or called green. A shared-target build-fingerprint setup failure was corrected by forcing the current crate rebuild; the three directly affected production-weighting plan tests then passed.

The current bounded cube lifecycle permits the development CLEAN runs under the fixed memory ceiling; the earlier all-channel admission rejection below is historical. **A complete full-input serial run, matched full-input CASA numerical/visual/timing acceptance, full bounded-memory acceptance, and the remaining T55/T57 obligations are still outstanding.** Worker scaling is not being used to conceal the serial gap. The 0.90 target is not achieved; no scope has been deferred.

### Quota stop and durable restart requirement

Brian added an account-wide weekly quota checkpoint: check the 10,080-minute window before every new trial and during long reasoning intervals; at **15% remaining or below**, start no new experiments, finish in-flight work at a safe boundary, publish a durable restart checkpoint, and pause pending explicit resumption. Slight overshoot is acceptable. Refreshed reading at this checkpoint: **20% remaining** (80% used; reset Unix 1789435318). This is not exact task billing and is not scientific completion.

Brian explicitly authorized pushing in-progress source and essential run/evidence state to the existing project remote. Source is verified above. A separate evidence snapshot is being prepared so the active controller's HEAD and immutable state are not changed by bookkeeping commits; it will preserve configuration/events, commands/results, rejected hypotheses, remaining acceptance, and restoration instructions without secrets, unrelated personal information or non-public datasets. No merge, release, cleanup or worktree deletion is authorized.

Next: one bounded independent GPT-6 Pro (Power 5) consultation is reviewing whether a versioned **private temporary** replay-file global commitment can hash its ordered checksum-bearing frame headers rather than hashing payload bytes a second time, preserving per-frame SHA and all immutable-seal/order/count/truncation checks. No implementation has been made and this is not the final independent T55 contract review. Interpret the review locally, check quota, then select only a distinct evidence-backed experiment.

## Earlier checkpoints and full-scope obligations (historical evidence)

### Earlier cube-first state

Committed checkpoint: `b7c482f72b7d8375dc86c97f96bc12248c734f15`; committed production checkpoint: `3ecbac5593fbb7fbba450365270c412b1b35456e`. The additional per-channel weighting correction is uncommitted WIP, with bounded development evidence below; it is not full ticket acceptance.

This draft is the canonical current implementation/evidence summary for the approved [T55/T57 cube-first amendment](https://github.com/bglenden/casa-rs/issues/486#issuecomment-5588851986), linked from #486, #541 and #543. All original T55/T57 scope, frozen #449 rows, #625 serial science acceptance, and the single final independent contract review remain required. The end-to-end 10x target applies to relatively large datasets, approximately 32 GB and larger, not the small development fixture. No partial merge or scope deferral is approved.

Natural-weighting serial Clark cube products pass all nine unchanged CASA checks. All seven products across every output channel were visually checked. Real W1/W2/W3 executions agree exactly on scientific arrays, image metadata and non-affine cycle evidence. The original channel-edge weight discrepancy and the test harness's unmatched restoration cutoff are resolved.

The matched per-channel Briggs(0.5) development comparison now passes all nine unchanged CASA checks. All six real Natural/Briggs W1/W2/W3 executions pass and agree exactly on scientific arrays, image metadata and non-affine cycle evidence. All seven products across all four channels were visually inspected for both weighting settings. Briggs normalized RMS differences are PSF 0.000162687, residual 0.000162252, image 0.000119572 and sum weights 0.000007986, below the unchanged 0.001 ceiling. Beam checks pass; PB and mask differences are zero. This small-fixture result is not large-data, speed or complete T55/T57 acceptance.

Astra XHigh localized the missing native endpoint weight; the canonical unflagged shifted-channel regression went red before the correction and is now green. Completed GPT-6 Pro (Power 5) consultation and locally verified pinned CASA/casacore source distinguish three stages: raw native-weight resampling into nominal padded density planes, one native scalar per mapped density plane, and nearest-native weight transfer alongside independently linear data interpolation. The existing owners now implement those stages using one payload-independent bounded row cursor and one shared fused/replay scalar calculation. Nominal CASA density extent is preserved rather than enlarged to hide missing support. No epsilon, flag substitution, tolerance relaxation or persistence change was used.

The consultation independently inspected the pinned Rust source but could not retrieve the pinned CASA source; supplied excerpts were verified locally. No new instrumented installed-CASA intermediate-density trace is claimed. The first real comparison wrapper failed final bookkeeping because it compared different source-key sets; an explicit reconciliation verified every saved source identity, unchanged original input, all six native results and both nine-check comparisons. That failed receipt remains retained. After the accounting and internal-identity changes, the final candidate completed the full six-case matrix and both nine-check comparisons again with a clean process-guard exit and verified unchanged source/input identities.

The application binding currently covers regular, multi-channel, linearly interpolated cubes. Moving-source, non-linear and single-output-channel variants are unfinished work, not approved exclusions. Frozen layout metadata and both raw-density/output-sum accumulator classes are charged through generation and replay; the new metadata has also been added to the cross-plan reservation. Further edge/metadata and full-scope acceptance remain required.

## Full-input timing checkpoint — blocked before execution

The user has reprioritized matched timing on the complete large input before further mode-coverage expansion. The small development fixture is not speed evidence. A new opt-in production-application timing test compiles and passes focused release Clippy; it preserves the complete input selection and explicit resource ceilings.

The full-cube CLEAN attempt was rejected during memory admission before visibility processing or product publication. The same request with existing allocation diagnostics confirmed the rejection. All worker candidates were infeasible: the dominant demands are all-channel operator grids and primitive outputs, not worker-private minor-cycle scratch. Natural weighting is not the large density allocation in this case. Current CLEAN planning bypasses the bounded channel-major initial path used without a minor cycle. This is a cube-residency prerequisite, not a measured runtime or a speed regression result.

No CASA timing, completed full-data native run, or speedup is claimed. No input reduction, memory-limit increase, production implementation change, or acceptance relaxation was made to force a result. Setup-only failures and both fast admission results remain retained locally. A bounded cube-memory correction needs an implementation decision before the requested matched pair can proceed. All remaining T55/T57 scope below remains required.

## Implemented ownership and preserved contracts

- Reconstruction owns channel-local Högbom/Clark prepared work and ordered commit. Runtime composes complete owner/worker/replay-window candidates before admission. Full-plane resident CLEAN, common thresholds and deterministic collection remain intact.
- Selected-row spectral geometry uses the first two selected native centres after prepared frame conversion. Separate prediction and accumulation roles preserve CASA's forward law, edge eligibility and image-frequency evaluation without fallback to unselected channels or channel-width guesses.
- The shared frequency conversion now mirrors CASA's scalar sidereal-time extraction. Its regression and direct reference checks preserve channel-edge coverage without an epsilon or tolerance change.
- Publication storage metadata is compiler-owned. Signed PB limits, numerical support, CLEAN search support and stored masks remain distinct; sinks serialize sealed metadata. CASA-interoperable persistence is unchanged.
- Production source compilation uses checked fixed-capacity arenas and bounded native prediction banks. Ordered compensated reduction and continuous framing preserve term order. No alternate production compiler remains.
- Transient compiler storage and retained artifact metadata are accounted separately. Runtime transfers existing admitted memory/storage permits only after successful work, fences and scientific sealing. Shared backing retains ownership across replay and releases at final drop; no release/reacquire gap or unaccounted alias is introduced.
- Disjoint compiler/minor-cycle workspaces share one admitted slot while retained metadata remains separately charged. The original admission and memory-floor assertions are unchanged.
- In-scope non-persistent ownership changes are approved. This does not authorize science/precision changes, CASA-persistence changes, scope reduction, relaxed resource limits, release or cleanup.

## Focused evidence at the committed checkpoints

Raw Cargo checks use `CARGO_INCREMENTAL=0`. Green results below belong to their committed checkpoints and do not accept the later per-channel candidate.

| Gate | Recorded result |
| --- | --- |
| `casa-types` library tests | 169 passed, including the scalar sidereal-time regression |
| Frequency C++ interoperability | 21 passed, one existing ignored |
| `casa-ms` spectral selection | 53 passed |
| Runtime execution and authority | 61 execution tests and 32 resource-authority tests passed |
| T55 admission gates | Both unchanged gates passed, including the original tight-memory fixture |
| Shared parallel replay | Six focused tests passed |
| Managed spill and receipt checks | 23 spill tests; 10 receipt tests passed, one existing ignored |
| Reconstruction retained compilation | 50 gridded tests plus shared-catalog and empty-frame binding checks passed |
| Application integration suite | 43 passed, one existing ignored, before the per-channel candidate |
| Affected checkpoint lint/format/docs checks | Passed at the recorded committed checkpoints |
| Matched Natural CASA comparison | All seven products and both beam checks passed unchanged tolerances; every channel visually inspected |
| Real worker determinism | All six original Natural/global-density-Briggs worker cases passed; this is not matched per-channel Briggs acceptance |
| Current per-channel candidate | Shifted canonical regression passes; all six matched real Natural/per-channel-Briggs worker cases and both nine-check CASA comparisons pass |
| Current weighting and spectral tests | 28 weighting tests and 14 spectral tests pass, including analytic native scalar, fused/replay identity, nominal extent, descending ties and independent flags |
| Current affected lint | Release Clippy for model, MS, reconstruction, runtime and application, all targets with warnings denied, passes |
| Current application and admission checks | All four canonical T55 cube application tests and both unchanged worker/memory-floor admission gates pass |
| Current internal identity contracts | All 35 compiled-problem and seven measurement-equation contract tests pass with the explicitly versioned cube-law encoding |

Earlier unaffected focused evidence remains retained for reconstruction units, weighting integration, bounded multi-frame major cycles, Taylor/joint replay, spectral sampling, publication products and compiled-problem contracts. Detailed commands, source identities, unsuccessful attempts and diagnostic artifacts are retained locally. This public summary intentionally omits workstation paths and detailed operational metadata.

The new field requires internal scientific identity migrations: compiled problem v25, science basis v4, prepared-artifact dependencies v2 and weighting commitment v5. Pinned digest assertions were recaptured after auditing those encoders; no identity assertion was removed. A stale pre-existing problem-version assertion in the directly affected measurement-equation test was migrated as well. These are internal identity changes, not CASA-interoperable format changes.

## Known failures and boundaries

- `just arch-check` is not green: stale migration/source identities and an existing paired-model trace failure were reproduced on the committed parent. No blind baseline refresh was made.
- Earlier complete-file fixture failures were reproduced on untouched source and are not represented as green. Tests were not weakened, deleted or ignored to obtain acceptance.
- Existing process-global mixed-mode storage-profile incompatibility remains an adjacent limitation. Test isolation does not constitute a production fix.
- Failed scientific runs and isolated kernel measurements are not end-to-end speed evidence.
- The current F64 compensated Numerics Contract remains binding. The Apple GPU compiler's native-double limitation is established, but the operation-scoped mixed-precision question is unanswered. No production F32 amendment or CPU fallback is authorized.

## Next acceptance boundary

After the user-directed full-input timing prerequisite is resolved, complete remaining cube-mode bindings and focused edge/metadata/resource checks; retain the locally verified source semantics and diagnostic history, and extend the proven linear-cube owner correction to the full approved acceptance matrix. Use a first-intermediate CASA trace for any remaining scientific discrepancy, and reuse unchanged CASA references. Preserve accumulated hypothesis/escalation history and the user's bounded execution checkpoints. No independent final contract review has yet accepted this candidate.

Representative/frozen #449 and #625 obligations, measured real input/compute overlap, complete T55/T57 resource/failure and performance gates, qualified actual GPU work, and the large-dataset 10x evidence remain required. Private framed-artifact identity goldens in the opt-in larger compiler probe require validated recapture before being claimed current. Consolidate the single independent contract review only at full ticket acceptance. No merge, release, cleanup or branch/worktree deletion has occurred.

